# End-to-End Debugging Guide - Application Insights Tracing

## Overview

This guide shows you how to trace the complete workflow from file upload to final output using Application Insights logs, traces, and errors.

---

## Complete Workflow Steps

```
1. File Upload → Bronze Container
   ↓
2. Blob Trigger Fires (start_orchestrator_on_blob)
   ↓
3. Orchestrator Starts (process_blob)
   ↓
4. File Type Detection
   ├─ Audio → speechToText
   ├─ Document → runDocIntel
   └─ Multimodal → callAoaiMultiModal
   ↓
5. Azure OpenAI Processing (callAoai)
   ↓
6. Write Results (writeToBlob)
   ↓
7. Complete
```

---

## Part 1: Setting Up Application Insights Queries

### Prerequisites

```bash
# Get Application Insights name
FUNCTION_APP_NAME="func-processing-xxzzexoimh2nw"
RESOURCE_GROUP="AzureGPTRAG-East2"

APP_INSIGHTS_NAME=$(az monitor app-insights component show \
  --resource-group $RESOURCE_GROUP \
  --query "[0].name" \
  --output tsv)

echo "Application Insights: $APP_INSIGHTS_NAME"
```

---

## Part 2: Step-by-Step Tracing Queries

### Step 1: File Upload Detection

**Query: Check if blob trigger fired**

```kusto
traces
| where timestamp > ago(1h)
| where message contains "Blob Trigger" 
   or message contains "start_orchestrator_on_blob"
   or message contains "Blob Received"
| project timestamp, message, severityLevel, customDimensions
| order by timestamp desc
```

**What to look for:**
- `"Blob Trigger (start_orchestrator_on_blob) - Blob Received"`
- `"path: bronze/{filename}"`
- `"Size: {bytes} bytes"`
- `"Started orchestration {instance_id}"`

**Expected Output:**
```
timestamp: 2025-01-15T10:30:00Z
message: "Blob Trigger (start_orchestrator_on_blob) - Blob Received: {blob_info}"
customDimensions: {
  "BlobName": "bronze/document.pdf",
  "BlobSize": "1024000",
  "InstanceId": "abc123-def456-..."
}
```

---

### Step 2: Orchestrator Started

**Query: Check orchestrator initialization**

```kusto
traces
| where timestamp > ago(1h)
| where message contains "process_blob" 
   or message contains "Process Blob sub Orchestration"
   or message contains "Processing blob_metadata"
| project timestamp, message, severityLevel, customDimensions
| order by timestamp desc
```

**What to look for:**
- `"Process Blob sub Orchestration - Processing blob_metadata"`
- `"sub orchestration id: {instance_id}"`
- File extension detection logs

**Expected Output:**
```
timestamp: 2025-01-15T10:30:05Z
message: "Process Blob sub Orchestration - Processing blob_metadata: {...}"
customDimensions: {
  "InstanceId": "abc123-def456-...",
  "BlobName": "document.pdf",
  "FileExtension": "pdf"
}
```

---

### Step 3: File Type Detection & Routing

**Query: Check file type detection**

```kusto
traces
| where timestamp > ago(1h)
| where message contains "Processing audio file"
   or message contains "Processing document file"
   or message contains "Unsupported file type"
| project timestamp, message, severityLevel
| order by timestamp desc
```

**What to look for:**
- `"Processing document file: {filename}"` (for PDFs, DOCX, etc.)
- `"Processing audio file: {filename}"` (for WAV, MP3, etc.)
- `"Unsupported file type: {extension}"` (if file type not supported)

**Expected Output:**
```
timestamp: 2025-01-15T10:30:06Z
message: "Processing document file: document.pdf"
```

---

### Step 4: Document Intelligence (runDocIntel)

**Query: Trace Document Intelligence execution**

```kusto
traces
| where timestamp > ago(1h)
| where message contains "runDocIntel"
   or message contains "Normalized Blob Name"
   or message contains "Starting analyze document"
   or message contains "Analyze document completed"
| project timestamp, message, severityLevel, customDimensions
| order by timestamp desc
```

**What to look for:**
- `"Normalized Blob Name: {name}"`
- `"Starting analyze document: {content_preview}..."`
- `"Analyze document completed with status: {status}"`
- Errors: `"Error processing {blob_input}: {error}"`

**Expected Output:**
```
timestamp: 2025-01-15T10:30:10Z
message: "Normalized Blob Name: document.pdf"

timestamp: 2025-01-15T10:30:12Z
message: "Starting analyze document: %PDF-1.4..."

timestamp: 2025-01-15T10:30:45Z
message: "Analyze document completed with status: {...}"
```

**Error Detection:**
```kusto
exceptions
| where timestamp > ago(1h)
| where outerMessage contains "runDocIntel"
   or outerMessage contains "DocumentIntelligence"
   or outerMessage contains "analyze document"
| project timestamp, outerMessage, details, customDimensions
| order by timestamp desc
```

---

### Step 5: Speech-to-Text (speechToText)

**Query: Trace Speech-to-Text execution**

```kusto
traces
| where timestamp > ago(1h)
| where message contains "speechToText"
   or message contains "Submitting transcription request"
   or message contains "Transcription completed"
   or message contains "Status: Succeeded"
| project timestamp, message, severityLevel
| order by timestamp desc
```

**What to look for:**
- `"Submitting transcription request for blob: {name}"`
- `"Status: Succeeded"` or `"Status: Failed"`
- `"Transcription completed successfully!"`
- Errors: `"Error during speech-to-text processing: {error}"`

**Expected Output:**
```
timestamp: 2025-01-15T10:30:10Z
message: "Submitting transcription request for blob: audio.wav"

timestamp: 2025-01-15T10:32:00Z
message: "Status: Succeeded"
message: "Transcription completed successfully!"
```

---

### Step 6: Azure OpenAI Call (callAoai)

**Query: Trace Azure OpenAI execution**

```kusto
traces
| where timestamp > ago(1h)
| where message contains "callAoai"
   or message contains "Full user prompt"
   or message contains "run_prompt"
   or message contains "User Prompt:"
   or message contains "System Prompt:"
| project timestamp, message, severityLevel, customDimensions
| order by timestamp desc
```

**What to look for:**
- `"callAoai.py: Full user prompt: {prompt}"`
- `"User Prompt: {user_prompt}"`
- `"System Prompt: {system_prompt}"`
- Errors: `"Error processing Sub Orchestration (callAoai): {error}"`
- Errors: `"Error calling OpenAI API: {error}"`

**Expected Output:**
```
timestamp: 2025-01-15T10:30:50Z
message: "callAoai.py: Full user prompt: {extracted_text}"

timestamp: 2025-01-15T10:30:51Z
message: "User Prompt: {user_prompt}"
message: "System Prompt: {system_prompt}"
```

**Error Detection:**
```kusto
exceptions
| where timestamp > ago(1h)
| where outerMessage contains "callAoai"
   or outerMessage contains "OpenAI"
   or outerMessage contains "AOAI"
| project timestamp, outerMessage, details, customDimensions
| order by timestamp desc
```

---

### Step 7: Write to Blob (writeToBlob)

**Query: Trace output writing**

```kusto
traces
| where timestamp > ago(1h)
| where message contains "writeToBlob"
   or message contains "Writing output to blob"
   or message contains "Successfully wrote output"
   or message contains "FINAL_OUTPUT_CONTAINER"
| project timestamp, message, severityLevel, customDimensions
| order by timestamp desc
```

**What to look for:**
- `"writeToBlob.py: Writing output to blob {filename}-output.json"`
- `"writeToBlob.py: Successfully wrote output to blob {name}"`
- `"writeToBlob.py: Result of write_to_blob: {result}"`
- Errors: `"Error writing output for blob {name}: {error}"`

**Expected Output:**
```
timestamp: 2025-01-15T10:31:00Z
message: "writeToBlob.py: Writing output to blob document-output.json"

timestamp: 2025-01-15T10:31:02Z
message: "writeToBlob.py: Successfully wrote output to blob document.pdf"
```

---

### Step 8: Orchestration Completion

**Query: Check orchestration status**

```kusto
traces
| where timestamp > ago(1h)
| where message contains "orchestration"
   or message contains "Completed"
   or message contains "Finished"
| project timestamp, message, severityLevel, customDimensions
| order by timestamp desc
```

**What to look for:**
- Orchestration completion messages
- Final status messages

---

## Part 3: Complete End-to-End Trace Query

### Single Query to See Entire Workflow

```kusto
// Complete workflow trace for a specific instance
let instanceId = "YOUR_INSTANCE_ID";  // Replace with actual instance ID
traces
| where timestamp > ago(24h)
| where customDimensions contains instanceId
   or message contains instanceId
| project timestamp, message, severityLevel, customDimensions
| order by timestamp asc
```

### Complete Workflow with All Steps

```kusto
traces
| where timestamp > ago(1h)
| where message contains "Blob Trigger" 
   or message contains "process_blob"
   or message contains "runDocIntel"
   or message contains "speechToText"
   or message contains "callAoai"
   or message contains "writeToBlob"
   or message contains "orchestration"
| extend Step = case(
    message contains "Blob Trigger", "1. Blob Upload",
    message contains "process_blob", "2. Orchestrator Start",
    message contains "runDocIntel", "3. Document Intelligence",
    message contains "speechToText", "3. Speech-to-Text",
    message contains "callAoai", "4. Azure OpenAI",
    message contains "writeToBlob", "5. Write Output",
    "Other"
)
| project timestamp, Step, message, severityLevel
| order by timestamp asc
```

---

## Part 4: Error Tracking

### All Errors in Workflow

```kusto
exceptions
| where timestamp > ago(24h)
| extend FunctionName = case(
    outerMessage contains "runDocIntel", "runDocIntel",
    outerMessage contains "speechToText", "speechToText",
    outerMessage contains "callAoai", "callAoai",
    outerMessage contains "writeToBlob", "writeToBlob",
    outerMessage contains "orchestration", "orchestrator",
    "Unknown"
)
| project timestamp, FunctionName, outerMessage, details, customDimensions
| order by timestamp desc
```

### Errors by Function

```kusto
exceptions
| where timestamp > ago(24h)
| extend FunctionName = case(
    outerMessage contains "runDocIntel", "Document Intelligence",
    outerMessage contains "speechToText", "Speech-to-Text",
    outerMessage contains "callAoai", "Azure OpenAI",
    outerMessage contains "writeToBlob", "Write Blob",
    outerMessage contains "orchestration", "Orchestrator",
    outerMessage contains "Configuration", "Configuration",
    "Other"
)
| summarize ErrorCount = count() by FunctionName
| order by ErrorCount desc
```

### Recent Errors with Details

```kusto
exceptions
| where timestamp > ago(1h)
| project timestamp, 
    Function = tostring(customDimensions.FunctionName),
    Error = outerMessage,
    Details = tostring(details[0].message),
    StackTrace = tostring(details[0].parsedStack)
| order by timestamp desc
| take 50
```

---

## Part 5: Performance Monitoring

### Execution Time by Step

```kusto
traces
| where timestamp > ago(24h)
| where message contains "Starting" or message contains "completed"
| extend Step = case(
    message contains "runDocIntel", "Document Intelligence",
    message contains "speechToText", "Speech-to-Text",
    message contains "callAoai", "Azure OpenAI",
    message contains "writeToBlob", "Write Blob",
    "Other"
)
| summarize 
    StartTime = minif(timestamp, message contains "Starting"),
    EndTime = maxif(timestamp, message contains "completed")
    by Step, bin(timestamp, 1h)
| extend Duration = EndTime - StartTime
| where Step != "Other"
| project Step, Duration, StartTime, EndTime
| order by StartTime desc
```

### Average Processing Time

```kusto
requests
| where timestamp > ago(24h)
| where name contains "orchestration" or name contains "activity"
| summarize 
    AvgDuration = avg(duration),
    MaxDuration = max(duration),
    MinDuration = min(duration),
    Count = count()
    by name, bin(timestamp, 1h)
| order by timestamp desc
```

---

## Part 6: Durable Functions Orchestration Tracking

### Get Orchestration Instance ID

```kusto
traces
| where timestamp > ago(1h)
| where message contains "Started orchestration"
| extend InstanceId = extract(@"([a-f0-9-]{36})", 1, message)
| project timestamp, InstanceId, message
| order by timestamp desc
| take 10
```

### Trace Specific Orchestration Instance

```kusto
let instanceId = "abc123-def456-ghi789";  // Replace with your instance ID
traces
| where timestamp > ago(24h)
| where message contains instanceId
   or customDimensions contains instanceId
| project timestamp, message, severityLevel, customDimensions
| order by timestamp asc
```

### Orchestration Status

```kusto
traces
| where timestamp > ago(1h)
| where message contains "orchestration"
| extend Status = case(
    message contains "Started", "Started",
    message contains "Running", "Running",
    message contains "Completed", "Completed",
    message contains "Failed", "Failed",
    "Unknown"
)
| summarize Count = count() by Status, bin(timestamp, 1h)
| order by timestamp desc
```

---

## Part 7: Common Error Patterns

### Storage/Blob Errors

```kusto
exceptions
| where timestamp > ago(24h)
| where outerMessage contains "Storage"
   or outerMessage contains "blob"
   or outerMessage contains "Blob"
   or outerMessage contains "queue"
| project timestamp, outerMessage, details
| order by timestamp desc
```

### Authentication/Authorization Errors

```kusto
exceptions
| where timestamp > ago(24h)
| where outerMessage contains "Unauthorized"
   or outerMessage contains "Forbidden"
   or outerMessage contains "authentication"
   or outerMessage contains "credential"
| project timestamp, outerMessage, details
| order by timestamp desc
```

### Configuration Errors

```kusto
exceptions
| where timestamp > ago(24h)
| where outerMessage contains "Configuration"
   or outerMessage contains "APP_CONFIGURATION"
   or outerMessage contains "config"
   or outerMessage contains "not found"
| project timestamp, outerMessage, details
| order by timestamp desc
```

### Azure OpenAI Errors

```kusto
exceptions
| where timestamp > ago(24h)
| where outerMessage contains "OpenAI"
   or outerMessage contains "AOAI"
   or outerMessage contains "rate limit"
   or outerMessage contains "quota"
| project timestamp, outerMessage, details
| order by timestamp desc
```

---

## Part 8: Using Azure CLI to Query Application Insights

### Query Traces

```bash
az monitor app-insights query \
  --app $APP_INSIGHTS_NAME \
  --resource-group $RESOURCE_GROUP \
  --analytics-query "traces | where timestamp > ago(1h) | where message contains 'Blob Trigger' | order by timestamp desc | take 10" \
  --output table
```

### Query Exceptions

```bash
az monitor app-insights query \
  --app $APP_INSIGHTS_NAME \
  --resource-group $RESOURCE_GROUP \
  --analytics-query "exceptions | where timestamp > ago(1h) | project timestamp, outerMessage | order by timestamp desc | take 10" \
  --output table
```

### Query Complete Workflow

```bash
az monitor app-insights query \
  --app $APP_INSIGHTS_NAME \
  --resource-group $RESOURCE_GROUP \
  --analytics-query "traces | where timestamp > ago(1h) | where message contains 'Blob Trigger' or message contains 'runDocIntel' or message contains 'callAoai' or message contains 'writeToBlob' | project timestamp, message | order by timestamp asc" \
  --output table
```

---

## Part 9: Real-Time Monitoring Dashboard Query

### Complete Workflow Status

```kusto
// Get latest orchestration status
let latestOrchestrations = traces
| where timestamp > ago(1h)
| where message contains "Started orchestration"
| extend InstanceId = extract(@"([a-f0-9-]{36})", 1, message)
| project InstanceId, StartTime = timestamp, BlobName = extract(@"bronze/(.+)", 1, message)
| distinct InstanceId, StartTime, BlobName;

let orchestrationStatus = traces
| where timestamp > ago(1h)
| extend InstanceId = extract(@"([a-f0-9-]{36})", 1, message)
| where isnotempty(InstanceId)
| extend Status = case(
    message contains "Completed", "Completed",
    message contains "Failed", "Failed",
    message contains "Running", "Running",
    "In Progress"
)
| summarize LatestStatus = arg_max(timestamp, Status) by InstanceId;

latestOrchestrations
| join kind=leftouter orchestrationStatus on InstanceId
| project InstanceId, BlobName, StartTime, Status = coalesce(LatestStatus, "In Progress")
| order by StartTime desc
```

---

## Part 10: Troubleshooting Checklist

### When File Upload Doesn't Trigger

1. **Check Blob Trigger:**
   ```kusto
   traces | where message contains "Blob Trigger" | where timestamp > ago(1h)
   ```

2. **Check Storage Connection:**
   ```kusto
   exceptions | where outerMessage contains "Storage" or outerMessage contains "blob"
   ```

3. **Verify Container Name:**
   - Should be `bronze`
   - Check blob path matches: `bronze/{name}`

### When Document Intelligence Fails

1. **Check runDocIntel Traces:**
   ```kusto
   traces | where message contains "runDocIntel" | where timestamp > ago(1h)
   ```

2. **Check for Authentication Errors:**
   ```kusto
   exceptions | where outerMessage contains "DocumentIntelligence" or outerMessage contains "Unauthorized"
   ```

3. **Verify Endpoint Configuration:**
   - Check `AIMULTISERVICES_ENDPOINT` is set correctly

### When Azure OpenAI Fails

1. **Check callAoai Traces:**
   ```kusto
   traces | where message contains "callAoai" | where timestamp > ago(1h)
   ```

2. **Check for Rate Limits:**
   ```kusto
   exceptions | where outerMessage contains "rate limit" or outerMessage contains "quota"
   ```

3. **Verify API Configuration:**
   - Check `OPENAI_API_BASE`, `OPENAI_API_VERSION`, `OPENAI_MODEL`

### When Write to Blob Fails

1. **Check writeToBlob Traces:**
   ```kusto
   traces | where message contains "writeToBlob" | where timestamp > ago(1h)
   ```

2. **Check Storage Permissions:**
   ```kusto
   exceptions | where outerMessage contains "Forbidden" or outerMessage contains "Access Denied"
   ```

3. **Verify Container Exists:**
   - Check `FINAL_OUTPUT_CONTAINER` setting

---

## Part 11: Sample Complete Trace Output

### Expected Trace Sequence

```
10:30:00 - "Blob Trigger (start_orchestrator_on_blob) - Blob Received: {blob}"
10:30:00 - "path: bronze/document.pdf"
10:30:00 - "Size: 1024000 bytes"
10:30:00 - "Started orchestration abc123-def456-... for blob bronze/document.pdf"

10:30:05 - "Process Blob sub Orchestration - Processing blob_metadata: {...}"
10:30:06 - "Processing document file: document.pdf"

10:30:10 - "Normalized Blob Name: document.pdf"
10:30:12 - "Starting analyze document: %PDF-1.4..."
10:30:45 - "Analyze document completed with status: {...}"

10:30:50 - "callAoai.py: Full user prompt: {extracted_text}"
10:30:51 - "User Prompt: {user_prompt}"
10:30:52 - "System Prompt: {system_prompt}"

10:31:00 - "writeToBlob.py: Writing output to blob document-output.json"
10:31:02 - "writeToBlob.py: Successfully wrote output to blob document.pdf"
```

---

## Quick Reference Commands

### Get Latest Instance ID
```bash
az monitor app-insights query \
  --app $APP_INSIGHTS_NAME \
  --resource-group $RESOURCE_GROUP \
  --analytics-query "traces | where message contains 'Started orchestration' | order by timestamp desc | take 1 | extend InstanceId = extract('([a-f0-9-]{36})', 1, message) | project InstanceId" \
  --output tsv
```

### Trace Specific Instance
```bash
INSTANCE_ID="your-instance-id"
az monitor app-insights query \
  --app $APP_INSIGHTS_NAME \
  --resource-group $RESOURCE_GROUP \
  --analytics-query "traces | where message contains '$INSTANCE_ID' | order by timestamp asc | project timestamp, message" \
  --output table
```

### Get All Errors for Last Hour
```bash
az monitor app-insights query \
  --app $APP_INSIGHTS_NAME \
  --resource-group $RESOURCE_GROUP \
  --analytics-query "exceptions | where timestamp > ago(1h) | project timestamp, outerMessage | order by timestamp desc" \
  --output table
```

---

This guide provides complete end-to-end tracing capabilities for debugging your Function App workflow!

