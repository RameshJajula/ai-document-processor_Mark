#!/bin/bash

# Bash Script to Check Function App Status
# Usage: ./check-function-app-status.sh

set -e

# Load environment variables from azd if available
if [ -f .azure/*.env ]; then
    echo "Loading environment variables from .azure/*.env"
    export $(grep -v '^#' .azure/*.env | xargs)
fi

# Use provided values or environment variables
FUNCTION_APP_NAME=${1:-$FUNCTION_APP_NAME}
RESOURCE_GROUP=${2:-$RESOURCE_GROUP}

if [ -z "$FUNCTION_APP_NAME" ] || [ -z "$RESOURCE_GROUP" ]; then
    echo "Error: Function App Name and Resource Group must be provided"
    echo "Usage: ./check-function-app-status.sh [function-app-name] [resource-group]"
    echo "Or set environment variables: FUNCTION_APP_NAME and RESOURCE_GROUP"
    exit 1
fi

echo "========================================"
echo "Function App Status Check"
echo "========================================"
echo "Function App: $FUNCTION_APP_NAME"
echo "Resource Group: $RESOURCE_GROUP"
echo ""

# 1. Check Function App Status
echo "1. Checking Function App Status..."
if app_status=$(az functionapp show \
    --name "$FUNCTION_APP_NAME" \
    --resource-group "$RESOURCE_GROUP" \
    --query "{Name:name, State:state, Status:defaultHostName, Runtime:siteConfig.linuxFxVersion}" \
    --output json 2>/dev/null); then
    
    echo "$app_status" | jq -r '
        "   Name: " + .Name,
        "   State: " + .State,
        "   URL: " + .Status,
        "   Runtime: " + .Runtime
    '
else
    echo "   Error checking function app status"
fi
echo ""

# 2. List Functions
echo "2. Listing Deployed Functions..."
if functions=$(az functionapp function list \
    --name "$FUNCTION_APP_NAME" \
    --resource-group "$RESOURCE_GROUP" \
    --output json 2>/dev/null); then
    
    func_count=$(echo "$functions" | jq '. | length')
    if [ "$func_count" -eq 0 ]; then
        echo "   Warning: No functions found!"
    else
        echo "   Found $func_count function(s):"
        echo "$functions" | jq -r '.[].name' | while read -r func_name; do
            echo "   - $func_name"
        done
    fi
else
    echo "   Error listing functions"
fi
echo ""

# 3. Check Deployment Status
echo "3. Checking Recent Deployment..."
if deployment=$(az functionapp log deployment show \
    --name "$FUNCTION_APP_NAME" \
    --resource-group "$RESOURCE_GROUP" \
    --output json 2>/dev/null); then
    
    if [ -n "$deployment" ] && [ "$deployment" != "null" ]; then
        echo "$deployment" | jq -r '
            "   Deployment ID: " + (.id // "N/A"),
            "   Status: " + (.status // "N/A" | tostring),
            "   Start Time: " + (.startTime // "N/A"),
            "   End Time: " + (.endTime // "N/A")
        '
    else
        echo "   No deployment information available"
    fi
else
    echo "   Error checking deployment"
fi
echo ""

# 4. Check Critical Configuration
echo "4. Checking Critical Configuration..."
if settings=$(az functionapp config appsettings list \
    --name "$FUNCTION_APP_NAME" \
    --resource-group "$RESOURCE_GROUP" \
    --output json 2>/dev/null); then
    
    critical_settings=(
        "FUNCTIONS_WORKER_RUNTIME"
        "FUNCTIONS_EXTENSION_VERSION"
        "APP_CONFIGURATION_URI"
        "AzureWebJobsStorage__accountName"
        "DataStorage__accountName"
    )
    
    for setting_name in "${critical_settings[@]}"; do
        value=$(echo "$settings" | jq -r ".[] | select(.name == \"$setting_name\") | .value")
        if [ -n "$value" ] && [ "$value" != "null" ]; then
            if [ ${#value} -gt 50 ]; then
                value="${value:0:50}..."
            fi
            echo "   $setting_name : $value"
        else
            echo "   $setting_name : NOT SET"
        fi
    done
else
    echo "   Error checking configuration"
fi
echo ""

# 5. Get Function Keys
echo "5. Checking Function Keys..."
if keys=$(az functionapp keys list \
    --name "$FUNCTION_APP_NAME" \
    --resource-group "$RESOURCE_GROUP" \
    --output json 2>/dev/null); then
    
    default_key=$(echo "$keys" | jq -r '.functionKeys.default // empty')
    if [ -n "$default_key" ] && [ "$default_key" != "null" ]; then
        echo "   Default Function Key: ${default_key:0:10}..."
    else
        echo "   Warning: No default function key found"
    fi
else
    echo "   Error retrieving function keys"
fi
echo ""

# 6. Check Application Insights
echo "6. Checking Application Insights Connection..."
if settings=$(az functionapp config appsettings list \
    --name "$FUNCTION_APP_NAME" \
    --resource-group "$RESOURCE_GROUP" \
    --output json 2>/dev/null); then
    
    app_insights_key=$(echo "$settings" | jq -r '.[] | select(.name == "APPINSIGHTS_INSTRUMENTATIONKEY") | .value')
    if [ -n "$app_insights_key" ] && [ "$app_insights_key" != "null" ]; then
        echo "   Application Insights: Connected"
    else
        echo "   Application Insights: Not configured"
    fi
else
    echo "   Error checking Application Insights"
fi
echo ""

echo "========================================"
echo "Status Check Complete"
echo "========================================"
echo ""
echo "Next Steps:"
echo "1. Review logs: az webapp log tail --name $FUNCTION_APP_NAME --resource-group $RESOURCE_GROUP"
echo "2. Check Application Insights for detailed traces and errors"
echo "3. Test HTTP endpoint: See DEBUG_GUIDE.md for testing commands"

