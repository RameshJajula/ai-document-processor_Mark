# Ramesh - Function App Debug Guide

This folder contains comprehensive debugging guides and tools for the AI Document Processor Function App.

## Contents

### 📘 [DEBUG_GUIDE.md](./DEBUG_GUIDE.md)
Complete debugging guide covering:
- Function app status checks
- Function deployment verification
- Logs and tracing
- Error investigation
- HTTP triggers testing
- Common issues and solutions

### 📋 [QUICK_REFERENCE.md](./QUICK_REFERENCE.md)
Quick reference for common debugging commands and queries.

### 🔐 [MANAGED_IDENTITY_ROLES_GUIDE.md](./MANAGED_IDENTITY_ROLES_GUIDE.md)
Comprehensive guide covering:
- Detailed PowerShell script analysis
- Complete workflow when files are uploaded
- All required managed identity roles
- Commands to check and fix missing roles
- Azure Portal step-by-step instructions

### 🔍 [END_TO_END_DEBUG_GUIDE.md](./END_TO_END_DEBUG_GUIDE.md)
Complete end-to-end debugging guide with:
- Step-by-step Application Insights queries
- Workflow tracing from file upload to completion
- Error tracking and troubleshooting
- Performance monitoring queries
- Durable Functions orchestration tracking

### 📖 [HOW_TO_RUN_QUERIES.md](./HOW_TO_RUN_QUERIES.md)
Practical guide showing exactly how to run the queries:
- Step-by-step instructions for each query
- Three methods: PowerShell script, Azure Portal, Azure CLI
- Copy-paste ready commands
- Troubleshooting tips

### 🔧 Helper Scripts

#### PowerShell Script (Windows)
- **File**: `check-function-app-status.ps1`
- **Usage**: 
  ```powershell
  .\check-function-app-status.ps1
  # Or with parameters:
  .\check-function-app-status.ps1 -FunctionAppName "func-app-name" -ResourceGroup "rg-name"
  ```
- **See**: [RUN_SCRIPT.md](./RUN_SCRIPT.md) for detailed execution instructions and troubleshooting
- **Features**:
  - Checks function app status
  - Lists all deployed functions
  - Shows deployment logs
  - Verifies critical configuration
  - Checks function keys
  - Validates Application Insights connection

#### Bash Script (Linux/Mac/WSL)
- **File**: `check-function-app-status.sh`
- **Usage**: 
  ```bash
  chmod +x check-function-app-status.sh
  ./check-function-app-status.sh
  # Or with parameters:
  ./check-function-app-status.sh "func-app-name" "rg-name"
  ```
- **Features**: Same as PowerShell script, optimized for Unix-like systems

#### Role Verification Script (PowerShell)
- **File**: `verify-managed-identity-roles.ps1`
- **Usage**: 
  ```powershell
  .\verify-managed-identity-roles.ps1 -FunctionAppName "func-app-name" -ResourceGroup "rg-name"
  ```
- **Features**:
  - Lists all current role assignments
  - Checks for required roles
  - Identifies missing roles
  - Provides next steps for fixing issues

#### Workflow Tracing Script (PowerShell)
- **File**: `trace-workflow.ps1`
- **Usage**: 
  ```powershell
  # Trace latest workflow
  .\trace-workflow.ps1 -FunctionAppName "func-app-name" -ResourceGroup "rg-name"
  
  # Trace specific instance
  .\trace-workflow.ps1 -FunctionAppName "func-app-name" -ResourceGroup "rg-name" -InstanceId "instance-id"
  ```
- **Features**:
  - Traces complete workflow from file upload to completion
  - Shows all steps: Blob Trigger → Orchestrator → Document Intelligence → Azure OpenAI → Write Output
  - Displays errors if any
  - Uses Application Insights queries

## Quick Start

### 1. Load Environment Variables
```bash
# If using azd
eval "$(azd env get-values)"

# Or manually set:
export FUNCTION_APP_NAME="your-function-app-name"
export RESOURCE_GROUP="your-resource-group"
```

### 2. Run Status Check Script
```bash
# Windows PowerShell
.\check-function-app-status.ps1

# Linux/Mac/WSL
./check-function-app-status.sh
```

### 3. Review Detailed Guide
Open [DEBUG_GUIDE.md](./DEBUG_GUIDE.md) for comprehensive debugging steps.

## Function App Overview

### Functions in This App

1. **HTTP Trigger**: `start_orchestrator_http`
   - Route: `/api/client`
   - Starts orchestration via HTTP POST

2. **Blob Trigger**: `start_orchestrator_on_blob`
   - Path: `bronze/{name}`
   - Automatically starts when blob is uploaded

3. **Orchestrator**: `process_blob`
   - Coordinates the document processing workflow

4. **Activity Functions**:
   - `callAoai` - Azure OpenAI processing
   - `callAoaiMultiModal` - Multimodal AI processing
   - `getBlobContent` - Blob retrieval
   - `runDocIntel` - Document Intelligence
   - `speechToText` - Audio transcription
   - `writeToBlob` - Output writing

## Common Debugging Scenarios

### Functions Not Appearing
1. Check deployment logs
2. Verify configuration settings
3. Check for authentication errors
4. Review Application Insights exceptions

### HTTP Trigger Not Working
1. Verify function key is included
2. Check function app status
3. Review request/response logs
4. Test with curl/Postman

### Orchestration Not Starting
1. Check durable client binding
2. Verify input format
3. Review orchestration logs
4. Check storage account permissions

### Activity Functions Failing
1. Check activity input parameters
2. Verify Azure service endpoints
3. Review activity-specific logs
4. Check timeout settings

## Resources

- [Azure Functions Documentation](https://learn.microsoft.com/azure/azure-functions/)
- [Durable Functions Documentation](https://learn.microsoft.com/azure/azure-functions/durable/)
- [Application Insights Query Documentation](https://learn.microsoft.com/azure/azure-monitor/logs/log-query-overview)
- [Azure CLI Function App Commands](https://learn.microsoft.com/cli/azure/functionapp)

## Support

For issues specific to this function app:
1. Review the [DEBUG_GUIDE.md](./DEBUG_GUIDE.md)
2. Check [QUICK_REFERENCE.md](./QUICK_REFERENCE.md) for command syntax
3. Run the status check scripts
4. Review Application Insights logs
5. Check the main project [README.md](../README.md) for deployment information

