# Quick Reference - Function App Debugging

## Prerequisites
```bash
# Load environment variables
eval "$(azd env get-values)"
# Or manually:
# export FUNCTION_APP_NAME="your-function-app-name"
# export RESOURCE_GROUP="your-resource-group"
```

## Essential Status Checks

### 1. Function App Status
```bash
az functionapp show \
  --name $FUNCTION_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --query "{Name:name, State:state, URL:defaultHostName}" \
  --output table
```

### 2. List All Functions
```bash
az functionapp function list \
  --name $FUNCTION_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --output table
```

### 3. Check Deployment Logs
```bash
az functionapp log deployment show \
  --name $FUNCTION_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --output table
```

### 4. Stream Logs in Real-Time
```bash
az webapp log tail \
  --name $FUNCTION_APP_NAME \
  --resource-group $RESOURCE_GROUP
```

### 5. Get Function Key
```bash
az functionapp keys list \
  --name $FUNCTION_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --query "functionKeys.default" \
  --output tsv
```

## Application Insights Queries

### Get Application Insights Name
```bash
APP_INSIGHTS_NAME=$(az monitor app-insights component show \
  --resource-group $RESOURCE_GROUP \
  --query "[0].name" \
  --output tsv)
```

### Recent Traces (Last Hour)
```bash
az monitor app-insights query \
  --app $APP_INSIGHTS_NAME \
  --resource-group $RESOURCE_GROUP \
  --analytics-query "traces | where timestamp > ago(1h) | order by timestamp desc | take 50" \
  --output table
```

### Recent Errors (Last 24 Hours)
```bash
az monitor app-insights query \
  --app $APP_INSIGHTS_NAME \
  --resource-group $RESOURCE_GROUP \
  --analytics-query "exceptions | where timestamp > ago(24h) | order by timestamp desc | take 20" \
  --output table
```

### HTTP Requests (Last Hour)
```bash
az monitor app-insights query \
  --app $APP_INSIGHTS_NAME \
  --resource-group $RESOURCE_GROUP \
  --analytics-query "requests | where timestamp > ago(1h) | project timestamp, name, success, resultCode, duration | order by timestamp desc" \
  --output table
```

### Function Executions
```bash
az monitor app-insights query \
  --app $APP_INSIGHTS_NAME \
  --resource-group $RESOURCE_GROUP \
  --analytics-query "traces | where message contains 'Function' | where timestamp > ago(1h) | order by timestamp desc | take 50" \
  --output table
```

## Testing HTTP Triggers

### Get Function Key
```bash
FUNCTION_KEY=$(az functionapp keys list \
  --name $FUNCTION_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --query "functionKeys.default" \
  --output tsv)
```

### Test /api/client Endpoint
```bash
curl -X POST "https://${FUNCTION_APP_NAME}.azurewebsites.net/api/client?code=${FUNCTION_KEY}" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "test-document.pdf",
    "uri": "https://yourstorageaccount.blob.core.windows.net/bronze/test-document.pdf"
  }' \
  -v
```

### Check Orchestration Status
```bash
INSTANCE_ID="your-instance-id-from-response"
curl -X GET "https://${FUNCTION_APP_NAME}.azurewebsites.net/runtime/webhooks/durabletask/instances/${INSTANCE_ID}?code=${FUNCTION_KEY}" \
  -H "Content-Type: application/json" | jq .
```

## Common Error Queries

### Storage Errors
```bash
az monitor app-insights query \
  --app $APP_INSIGHTS_NAME \
  --resource-group $RESOURCE_GROUP \
  --analytics-query "exceptions | where outerMessage contains 'Storage' or outerMessage contains 'blob' or outerMessage contains 'queue' | where timestamp > ago(24h) | project timestamp, outerMessage | order by timestamp desc" \
  --output table
```

### Configuration Errors
```bash
az monitor app-insights query \
  --app $APP_INSIGHTS_NAME \
  --resource-group $RESOURCE_GROUP \
  --analytics-query "exceptions | where outerMessage contains 'Configuration' or outerMessage contains 'APP_CONFIGURATION' | where timestamp > ago(24h) | project timestamp, outerMessage | order by timestamp desc" \
  --output table
```

### Azure OpenAI Errors
```bash
az monitor app-insights query \
  --app $APP_INSIGHTS_NAME \
  --resource-group $RESOURCE_GROUP \
  --analytics-query "exceptions | where outerMessage contains 'OpenAI' or outerMessage contains 'AOAI' | where timestamp > ago(24h) | project timestamp, outerMessage | order by timestamp desc" \
  --output table
```

## Configuration Checks

### List All App Settings
```bash
az functionapp config appsettings list \
  --name $FUNCTION_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --output table
```

### Check Critical Settings
```bash
az functionapp config appsettings list \
  --name $FUNCTION_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --query "[?name=='FUNCTIONS_WORKER_RUNTIME' || name=='APP_CONFIGURATION_URI' || name=='FUNCTIONS_EXTENSION_VERSION'].{Name:name, Value:value}" \
  --output table
```

## Function-Specific Checks

### Check Specific Function
```bash
FUNCTION_NAME="start_orchestrator_http"
az functionapp function show \
  --name $FUNCTION_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --function-name $FUNCTION_NAME \
  --output json | jq .
```

### Check Function Status (Enabled/Disabled)
```bash
az functionapp function show \
  --name $FUNCTION_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --function-name $FUNCTION_NAME \
  --query "properties.config.disabled" \
  --output tsv
```

## Using Helper Scripts

### PowerShell (Windows)
```powershell
.\check-function-app-status.ps1
# Or with parameters:
.\check-function-app-status.ps1 -FunctionAppName "func-app-name" -ResourceGroup "rg-name"
```

### Bash (Linux/Mac/WSL)
```bash
chmod +x check-function-app-status.sh
./check-function-app-status.sh
# Or with parameters:
./check-function-app-status.sh "func-app-name" "rg-name"
```

## Function App Functions Reference

### HTTP Trigger
- **Name**: `start_orchestrator_http`
- **Route**: `/api/client`
- **Method**: POST
- **Auth**: Function Key required

### Blob Trigger
- **Name**: `start_orchestrator_on_blob`
- **Path**: `bronze/{name}`
- **Connection**: `DataStorage`

### Orchestrator
- **Name**: `process_blob`
- **Type**: Durable Functions Orchestrator

### Activity Functions
- `callAoai` - Azure OpenAI text processing
- `callAoaiMultiModal` - Azure OpenAI multimodal processing
- `getBlobContent` - Retrieve blob content
- `runDocIntel` - Document Intelligence OCR
- `speechToText` - Speech-to-text conversion
- `writeToBlob` - Write output to blob storage

## Troubleshooting Checklist

- [ ] Function app is in "Running" state
- [ ] All functions are deployed and visible
- [ ] Critical app settings are configured
- [ ] Function keys are available
- [ ] Application Insights is connected
- [ ] Storage account connections are working
- [ ] Managed identity has required roles
- [ ] No errors in recent logs
- [ ] HTTP triggers respond correctly
- [ ] Orchestrations start successfully

## Quick Links

- **Azure Portal**: https://portal.azure.com
- **Function App**: Navigate to Function App → Functions
- **Log Stream**: Function App → Log stream
- **Application Insights**: Function App → Monitor → Logs
- **Deployment Center**: Function App → Deployment Center
- **Configuration**: Function App → Configuration

