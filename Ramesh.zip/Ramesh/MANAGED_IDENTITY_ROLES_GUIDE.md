# Managed Identity Roles Guide for Function App

## Overview

This guide explains:
1. What the PowerShell script does (detailed analysis)
2. The complete workflow when a file is uploaded to the bronze container
3. All required managed identity roles
4. How to check for missing roles
5. Commands and Azure Portal steps to fix missing roles

---

## Part 1: PowerShell Script Analysis (Lines 1-84)

### Script Purpose
The `check-function-app-status.ps1` script performs a comprehensive health check of your Azure Function App by running 6 diagnostic checks.

### Detailed Breakdown

#### **Lines 1-7: Script Parameters**
```powershell
param(
    [string]$FunctionAppName = "",
    [string]$ResourceGroup = ""
)
```
- Accepts Function App name and Resource Group as parameters
- Both are optional - script will use environment variables if not provided

#### **Lines 9-25: Environment Variable Loading**
```powershell
$envPath = ".\.azure"
if (Test-Path $envPath) {
    $envFiles = Get-ChildItem -Path $envPath -Filter "*.env" -ErrorAction SilentlyContinue
    ...
}
```
- **What it does**: Automatically loads environment variables from `.azure/*.env` files (created by `azd`)
- **Why**: Eliminates need to manually set variables each time
- **Sets**: `FUNCTION_APP_NAME`, `RESOURCE_GROUP`, and other Azure deployment variables

#### **Lines 27-40: Parameter Validation**
```powershell
if ([string]::IsNullOrEmpty($FunctionAppName)) {
    $FunctionAppName = $env:FUNCTION_APP_NAME
}
```
- **What it does**: Uses provided parameters OR falls back to environment variables
- **Validates**: Ensures both Function App name and Resource Group are present
- **Exits**: If missing, shows usage instructions and exits with error code 1

#### **Lines 49-64: Check 1 - Function App Status**
```powershell
$appStatus = az functionapp show `
    --name $FunctionAppName `
    --resource-group $ResourceGroup `
    --query "{Name:name, State:state, Status:defaultHostName, Runtime:siteConfig.linuxFxVersion}" `
    --output json | ConvertFrom-Json
```
- **Azure CLI Command**: `az functionapp show`
- **Retrieves**:
  - Function App name
  - Current state (Running, Stopped, etc.)
  - Default hostname (URL)
  - Runtime version (Python|3.11)
- **Output**: Color-coded status (Green if Running, Red if not)
- **Purpose**: Confirms Function App exists and is operational

#### **Lines 67-85: Check 2 - List Deployed Functions**
```powershell
$functions = az functionapp function list `
    --name $FunctionAppName `
    --resource-group $ResourceGroup `
    --output json | ConvertFrom-Json
```
- **Azure CLI Command**: `az functionapp function list`
- **Retrieves**: All functions deployed to the Function App
- **Shows**: Function names, counts total functions
- **Purpose**: Verifies all functions deployed successfully
- **Critical**: If count is 0, functions didn't deploy (common issue!)

#### **Lines 88-106: Check 3 - Deployment Status**
```powershell
$deployment = az functionapp log deployment show `
    --name $FunctionAppName `
    --resource-group $ResourceGroup `
    --output json | ConvertFrom-Json
```
- **Azure CLI Command**: `az functionapp log deployment show`
- **Retrieves**: Most recent deployment information
- **Shows**: Deployment ID, status code (4 = Success), start/end times
- **Purpose**: Confirms last deployment completed successfully

#### **Lines 109-136: Check 4 - Critical Configuration**
```powershell
$settings = az functionapp config appsettings list `
    --name $FunctionAppName `
    --resource-group $ResourceGroup `
    --output json | ConvertFrom-Json
```
- **Azure CLI Command**: `az functionapp config appsettings list`
- **Checks 5 Critical Settings**:
  1. `FUNCTIONS_WORKER_RUNTIME` - Python runtime
  2. `FUNCTIONS_EXTENSION_VERSION` - Functions runtime version
  3. `APP_CONFIGURATION_URI` - App Configuration endpoint
  4. `AzureWebJobsStorage__accountName` - Storage for Functions runtime
  5. `DataStorage__accountName` - Storage for blob data
- **Purpose**: Verifies required configuration is present
- **Shows**: "NOT SET" in red if missing (indicates problem)

#### **Lines 139-154: Check 5 - Function Keys**
```powershell
$keys = az functionapp keys list `
    --name $FunctionAppName `
    --resource-group $ResourceGroup `
    --output json | ConvertFrom-Json
```
- **Azure CLI Command**: `az functionapp keys list`
- **Retrieves**: Default function key (for HTTP trigger authentication)
- **Shows**: First 10 characters only (for security)
- **Purpose**: Confirms HTTP triggers can be called

#### **Lines 157-168: Check 6 - Application Insights**
```powershell
$appInsightsKey = ($settings | Where-Object { $_.name -eq "APPINSIGHTS_INSTRUMENTATIONKEY" }).value
```
- **Checks**: If `APPINSIGHTS_INSTRUMENTATIONKEY` is configured
- **Purpose**: Verifies logging/monitoring is set up
- **Shows**: "Connected" (Green) or "Not configured" (Yellow)

---

## Part 2: Complete Workflow When File is Uploaded to Bronze Container

### Step-by-Step Process Flow

```
1. File Upload → Bronze Container
   ↓
2. Blob Trigger Fires (start_orchestrator_on_blob)
   ↓
3. Orchestrator Starts (process_blob)
   ↓
4. File Type Detection
   ├─ Audio → speechToText
   ├─ Document → runDocIntel
   └─ Multimodal → callAoaiMultiModal
   ↓
5. Text Extraction Complete
   ↓
6. Azure OpenAI Processing (callAoai)
   ↓
7. Write Results to Final Output Container (writeToBlob)
```

### Detailed Workflow

#### **Step 1: Blob Upload Trigger**
- **Function**: `start_orchestrator_on_blob`
- **Trigger**: Blob uploaded to `bronze/{name}` container
- **Connection**: Uses `DataStorage` connection string
- **Action**: Automatically starts orchestration

#### **Step 2: Orchestration Starts**
- **Function**: `process_blob` (Durable Functions Orchestrator)
- **Input**: Blob metadata (name, container, URI)
- **Action**: Determines file type and routes to appropriate processor

#### **Step 3: File Processing (Based on Type)**

**For Audio Files** (wav, mp3, opus, ogg, flac, wma, aac, webm):
- **Function**: `speechToText`
- **Service**: Azure Speech-to-Text (via AI Multi-Services)
- **Output**: Transcribed text

**For Documents** (pdf, docx, doc, xlsx, pptx, jpg, jpeg, png, tiff, bmp):
- **Function**: `runDocIntel`
- **Service**: Azure Document Intelligence
- **Output**: Extracted text from document

**For Multimodal** (if enabled):
- **Function**: `callAoaiMultiModal`
- **Service**: Azure OpenAI with vision capabilities
- **Output**: Extracted insights from images/PDFs

#### **Step 4: Azure OpenAI Processing**
- **Function**: `callAoai`
- **Service**: Azure OpenAI
- **Input**: Extracted text + prompts from App Configuration
- **Output**: JSON with insights/structured data

#### **Step 5: Write Results**
- **Function**: `writeToBlob`
- **Destination**: Final output container (e.g., `silver` or configured container)
- **Format**: JSON file named `{original-filename}-output.json`

---

## Part 3: Required Managed Identity Roles

### Function App Managed Identity
The Function App uses a **User-Assigned Managed Identity** named `uaiFrontendMsi` (or similar based on your deployment).

### Complete List of Required Roles

#### **1. Storage Account Roles**

##### **Storage Blob Data Owner** (Required)
- **Role ID**: `b7e6dc6d-f1e8-4753-8033-0f276bb0955b`
- **Scope**: Storage Account (DataStorage)
- **Purpose**: 
  - Read blobs from `bronze` container
  - Write blobs to final output container
  - Access blob metadata
- **Used By**: 
  - `get_blob_content()` in `blob_functions.py`
  - `write_to_blob()` in `blob_functions.py`
  - Blob trigger binding

##### **Storage Queue Data Contributor** (Required)
- **Role ID**: `974c5e8b-45b9-4653-ba55-5f855dd0fb88`
- **Scope**: Storage Account (AzureWebJobsStorage)
- **Purpose**: 
  - Durable Functions state management
  - Orchestration queue operations
- **Used By**: Durable Functions runtime

##### **Storage Table Data Contributor** (Required)
- **Role ID**: `0a9a7e1f-b9d0-4cc4-a60d-0319b160aaa3`
- **Scope**: Storage Account (AzureWebJobsStorage)
- **Purpose**: 
  - Durable Functions history table
  - Orchestration state storage
- **Used By**: Durable Functions runtime

##### **Storage Account Contributor** (Required)
- **Role ID**: `17d1049b-9a84-46fb-8f53-869881c3d3ab`
- **Scope**: Resource Group or Storage Account
- **Purpose**: 
  - Manage storage account properties
  - Access storage account metadata
- **Used By**: Function App runtime

#### **2. App Configuration Roles**

##### **App Configuration Data Owner** (Required)
- **Role ID**: `5ae67dd6-50cb-40e7-96ff-dc2bfa4b606b`
- **Scope**: App Configuration instance
- **Purpose**: 
  - Read configuration values
  - Access Key Vault references
  - Load prompts and settings
- **Used By**: 
  - `Configuration` class in `configuration.py`
  - `load_prompts()` in `prompts.py`

#### **3. Azure OpenAI / Cognitive Services Roles**

##### **Cognitive Services OpenAI User** (Required)
- **Role ID**: `5e0bd9bd-7b93-4f28-af87-19fc36ad61bd`
- **Scope**: Azure OpenAI resource
- **Purpose**: 
  - Call Azure OpenAI API
  - Generate completions
  - Access embeddings
- **Used By**: 
  - `run_prompt()` in `azure_openai.py`
  - `callAoai` activity function
  - `callAoaiMultiModal` activity function

##### **Cognitive Services User** (Required)
- **Role ID**: `a97b65f3-24c7-4388-baec-2e87135dc908`
- **Scope**: AI Multi-Services resource
- **Purpose**: 
  - Access Document Intelligence
  - Access Speech-to-Text services
- **Used By**: 
  - `runDocIntel` activity function
  - `speechToText` activity function

#### **4. Resource Group Roles**

##### **Contributor** (Required)
- **Role ID**: `b24988ac-6180-42a0-ab88-20f7382dd24c`
- **Scope**: Resource Group
- **Purpose**: 
  - General resource management
  - Access to resources in the resource group
- **Used By**: Function App runtime operations

#### **5. Key Vault Roles** (If Using Key Vault References)

##### **Key Vault Secrets User** (Required if using Key Vault)
- **Role ID**: `4633458b-17de-408a-b874-0445c86b69e6`
- **Scope**: Key Vault
- **Purpose**: 
  - Read secrets from Key Vault
  - Access secrets referenced in App Configuration
- **Used By**: App Configuration when resolving Key Vault references

---

## Part 4: Checking for Missing Roles

### Method 1: Using Azure CLI

#### Get Function App Managed Identity
```bash
# Get the managed identity client ID
FUNCTION_APP_NAME="func-processing-xxzzexoimh2nw"
RESOURCE_GROUP="AzureGPTRAG-East2"

# Get managed identity client ID
MANAGED_IDENTITY_CLIENT_ID=$(az functionapp identity show \
  --name $FUNCTION_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --query "userAssignedIdentities.*.clientId" \
  --output tsv)

echo "Managed Identity Client ID: $MANAGED_IDENTITY_CLIENT_ID"

# Get managed identity principal ID
MANAGED_IDENTITY_PRINCIPAL_ID=$(az functionapp identity show \
  --name $FUNCTION_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --query "userAssignedIdentities.*.principalId" \
  --output tsv)

echo "Managed Identity Principal ID: $MANAGED_IDENTITY_PRINCIPAL_ID"
```

#### Check Storage Account Roles
```bash
# Get storage account name
STORAGE_ACCOUNT=$(az functionapp config appsettings list \
  --name $FUNCTION_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --query "[?name=='DataStorage__accountName'].value" \
  --output tsv)

# Check Storage Blob Data Owner role
az role assignment list \
  --assignee $MANAGED_IDENTITY_PRINCIPAL_ID \
  --scope "/subscriptions/$(az account show --query id -o tsv)/resourceGroups/$RESOURCE_GROUP/providers/Microsoft.Storage/storageAccounts/$STORAGE_ACCOUNT" \
  --query "[?roleDefinitionName=='Storage Blob Data Owner']" \
  --output table

# Check Storage Queue Data Contributor role
az role assignment list \
  --assignee $MANAGED_IDENTITY_PRINCIPAL_ID \
  --scope "/subscriptions/$(az account show --query id -o tsv)/resourceGroups/$RESOURCE_GROUP/providers/Microsoft.Storage/storageAccounts/$STORAGE_ACCOUNT" \
  --query "[?roleDefinitionName=='Storage Queue Data Contributor']" \
  --output table
```

#### Check App Configuration Roles
```bash
# Get App Configuration name
APP_CONFIG_NAME=$(az appconfig list \
  --resource-group $RESOURCE_GROUP \
  --query "[0].name" \
  --output tsv)

# Check App Configuration Data Owner role
az role assignment list \
  --assignee $MANAGED_IDENTITY_PRINCIPAL_ID \
  --scope "/subscriptions/$(az account show --query id -o tsv)/resourceGroups/$RESOURCE_GROUP/providers/Microsoft.AppConfiguration/configurationStores/$APP_CONFIG_NAME" \
  --query "[?roleDefinitionName=='App Configuration Data Owner']" \
  --output table
```

#### Check Azure OpenAI Roles
```bash
# Get Azure OpenAI resource name (from App Configuration or environment)
AOAI_RESOURCE=$(az cognitiveservices account list \
  --resource-group $RESOURCE_GROUP \
  --query "[?kind=='OpenAI'].name" \
  --output tsv)

# Check Cognitive Services OpenAI User role
az role assignment list \
  --assignee $MANAGED_IDENTITY_PRINCIPAL_ID \
  --scope "/subscriptions/$(az account show --query id -o tsv)/resourceGroups/$RESOURCE_GROUP/providers/Microsoft.CognitiveServices/accounts/$AOAI_RESOURCE" \
  --query "[?roleDefinitionName=='Cognitive Services OpenAI User']" \
  --output table
```

#### Check All Roles at Once
```bash
# List all role assignments for the managed identity
az role assignment list \
  --assignee $MANAGED_IDENTITY_PRINCIPAL_ID \
  --all \
  --output table
```

### Method 2: Using PowerShell Script

Create a script to check all roles:

```powershell
# check-roles.ps1
param(
    [string]$FunctionAppName = "",
    [string]$ResourceGroup = ""
)

# Get managed identity
$identity = az functionapp identity show `
    --name $FunctionAppName `
    --resource-group $ResourceGroup `
    --output json | ConvertFrom-Json

$principalId = ($identity.userAssignedIdentities.PSObject.Properties | Select-Object -First 1).Value.principalId

Write-Host "Checking roles for Principal ID: $principalId" -ForegroundColor Cyan

# Required roles
$requiredRoles = @(
    "Storage Blob Data Owner",
    "Storage Queue Data Contributor",
    "Storage Table Data Contributor",
    "App Configuration Data Owner",
    "Cognitive Services OpenAI User",
    "Cognitive Services User",
    "Contributor"
)

foreach ($role in $requiredRoles) {
    $assignments = az role assignment list `
        --assignee $principalId `
        --role "$role" `
        --all `
        --output json | ConvertFrom-Json
    
    if ($assignments.Count -gt 0) {
        Write-Host "✓ $role - ASSIGNED" -ForegroundColor Green
    } else {
        Write-Host "✗ $role - MISSING" -ForegroundColor Red
    }
}
```

---

## Part 5: Fixing Missing Roles - Azure CLI Commands

### Prerequisites
```bash
# Set variables
FUNCTION_APP_NAME="func-processing-xxzzexoimh2nw"
RESOURCE_GROUP="AzureGPTRAG-East2"
SUBSCRIPTION_ID=$(az account show --query id -o tsv)

# Get managed identity principal ID
MANAGED_IDENTITY_PRINCIPAL_ID=$(az functionapp identity show \
  --name $FUNCTION_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --query "userAssignedIdentities.*.principalId" \
  --output tsv)
```

### 1. Assign Storage Blob Data Owner Role
```bash
# Get storage account name
STORAGE_ACCOUNT=$(az functionapp config appsettings list \
  --name $FUNCTION_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --query "[?name=='DataStorage__accountName'].value" \
  --output tsv)

# Assign role
az role assignment create \
  --assignee $MANAGED_IDENTITY_PRINCIPAL_ID \
  --role "Storage Blob Data Owner" \
  --scope "/subscriptions/$SUBSCRIPTION_ID/resourceGroups/$RESOURCE_GROUP/providers/Microsoft.Storage/storageAccounts/$STORAGE_ACCOUNT"
```

### 2. Assign Storage Queue Data Contributor Role
```bash
# Get function app storage account (for Durable Functions)
FUNC_STORAGE=$(az functionapp config appsettings list \
  --name $FUNCTION_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --query "[?name=='AzureWebJobsStorage__accountName'].value" \
  --output tsv)

# Assign role
az role assignment create \
  --assignee $MANAGED_IDENTITY_PRINCIPAL_ID \
  --role "Storage Queue Data Contributor" \
  --scope "/subscriptions/$SUBSCRIPTION_ID/resourceGroups/$RESOURCE_GROUP/providers/Microsoft.Storage/storageAccounts/$FUNC_STORAGE"
```

### 3. Assign Storage Table Data Contributor Role
```bash
az role assignment create \
  --assignee $MANAGED_IDENTITY_PRINCIPAL_ID \
  --role "Storage Table Data Contributor" \
  --scope "/subscriptions/$SUBSCRIPTION_ID/resourceGroups/$RESOURCE_GROUP/providers/Microsoft.Storage/storageAccounts/$FUNC_STORAGE"
```

### 4. Assign App Configuration Data Owner Role
```bash
# Get App Configuration name
APP_CONFIG_NAME=$(az appconfig list \
  --resource-group $RESOURCE_GROUP \
  --query "[0].name" \
  --output tsv)

# Assign role
az role assignment create \
  --assignee $MANAGED_IDENTITY_PRINCIPAL_ID \
  --role "App Configuration Data Owner" \
  --scope "/subscriptions/$SUBSCRIPTION_ID/resourceGroups/$RESOURCE_GROUP/providers/Microsoft.AppConfiguration/configurationStores/$APP_CONFIG_NAME"
```

### 5. Assign Cognitive Services OpenAI User Role
```bash
# Get Azure OpenAI resource name
AOAI_RESOURCE=$(az cognitiveservices account list \
  --resource-group $RESOURCE_GROUP \
  --query "[?kind=='OpenAI'].name" \
  --output tsv)

# Assign role
az role assignment create \
  --assignee $MANAGED_IDENTITY_PRINCIPAL_ID \
  --role "Cognitive Services OpenAI User" \
  --scope "/subscriptions/$SUBSCRIPTION_ID/resourceGroups/$RESOURCE_GROUP/providers/Microsoft.CognitiveServices/accounts/$AOAI_RESOURCE"
```

### 6. Assign Cognitive Services User Role
```bash
# Get AI Multi-Services resource name
AI_MULTI_SERVICES=$(az cognitiveservices account list \
  --resource-group $RESOURCE_GROUP \
  --query "[?kind=='AIServices'].name" \
  --output tsv)

# Assign role
az role assignment create \
  --assignee $MANAGED_IDENTITY_PRINCIPAL_ID \
  --role "Cognitive Services User" \
  --scope "/subscriptions/$SUBSCRIPTION_ID/resourceGroups/$RESOURCE_GROUP/providers/Microsoft.CognitiveServices/accounts/$AI_MULTI_SERVICES"
```

### 7. Assign Contributor Role (Resource Group)
```bash
az role assignment create \
  --assignee $MANAGED_IDENTITY_PRINCIPAL_ID \
  --role "Contributor" \
  --scope "/subscriptions/$SUBSCRIPTION_ID/resourceGroups/$RESOURCE_GROUP"
```

### 8. Assign Key Vault Secrets User (If Using Key Vault)
```bash
# Get Key Vault name
KEY_VAULT_NAME=$(az keyvault list \
  --resource-group $RESOURCE_GROUP \
  --query "[0].name" \
  --output tsv)

# Assign role
az role assignment create \
  --assignee $MANAGED_IDENTITY_PRINCIPAL_ID \
  --role "Key Vault Secrets User" \
  --scope "/subscriptions/$SUBSCRIPTION_ID/resourceGroups/$RESOURCE_GROUP/providers/Microsoft.KeyVault/vaults/$KEY_VAULT_NAME"
```

---

## Part 6: Fixing Missing Roles - Azure Portal Steps

### Step 1: Find the Managed Identity

1. Navigate to **Azure Portal** → **Function App** → Your Function App
2. Go to **Settings** → **Identity**
3. Under **User assigned** tab, note the managed identity name
4. Click on the managed identity name to open it

### Step 2: Assign Storage Account Roles

#### Storage Blob Data Owner
1. Navigate to **Storage Account** → Your Data Storage Account
2. Go to **Access control (IAM)**
3. Click **+ Add** → **Add role assignment**
4. Select **Storage Blob Data Owner**
5. Click **Next**
6. Under **Assign access to**, select **Managed identity**
7. Click **+ Select members**
8. Search for and select your Function App's managed identity
9. Click **Select** → **Next** → **Review + assign**

#### Storage Queue Data Contributor
1. Navigate to **Storage Account** → Your Function App Storage Account (for Durable Functions)
2. Go to **Access control (IAM)**
3. Click **+ Add** → **Add role assignment**
4. Select **Storage Queue Data Contributor**
5. Follow steps 6-9 above

#### Storage Table Data Contributor
1. Same storage account as above
2. Follow same steps, but select **Storage Table Data Contributor**

### Step 3: Assign App Configuration Role

1. Navigate to **App Configuration** → Your App Configuration instance
2. Go to **Access control (IAM)**
3. Click **+ Add** → **Add role assignment**
4. Select **App Configuration Data Owner**
5. Follow steps 6-9 from above

### Step 4: Assign Azure OpenAI Role

1. Navigate to **Cognitive Services** → Your Azure OpenAI resource
2. Go to **Access control (IAM)**
3. Click **+ Add** → **Add role assignment**
4. Select **Cognitive Services OpenAI User**
5. Follow steps 6-9 from above

### Step 5: Assign AI Multi-Services Role

1. Navigate to **Cognitive Services** → Your AI Multi-Services resource
2. Go to **Access control (IAM)**
3. Click **+ Add** → **Add role assignment**
4. Select **Cognitive Services User**
5. Follow steps 6-9 from above

### Step 6: Assign Resource Group Contributor Role

1. Navigate to **Resource Groups** → Your Resource Group
2. Go to **Access control (IAM)**
3. Click **+ Add** → **Add role assignment**
4. Select **Contributor**
5. Follow steps 6-9 from above

---

## Part 7: Verification Script

### Complete Role Verification Script

```powershell
# verify-roles.ps1
param(
    [string]$FunctionAppName = "",
    [string]$ResourceGroup = ""
)

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Managed Identity Roles Verification" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan

# Get managed identity
$identityJson = az functionapp identity show `
    --name $FunctionAppName `
    --resource-group $ResourceGroup `
    --output json 2>&1

if ($LASTEXITCODE -ne 0) {
    Write-Host "Error: Could not retrieve managed identity" -ForegroundColor Red
    exit 1
}

$identity = $identityJson | ConvertFrom-Json
$principalId = ($identity.userAssignedIdentities.PSObject.Properties | Select-Object -First 1).Value.principalId

Write-Host "Managed Identity Principal ID: $principalId" -ForegroundColor White
Write-Host ""

# Get all role assignments
$allAssignments = az role assignment list `
    --assignee $principalId `
    --all `
    --output json | ConvertFrom-Json

Write-Host "Current Role Assignments:" -ForegroundColor Green
$allAssignments | ForEach-Object {
    Write-Host "  - $($_.roleDefinitionName) on $($_.scope)" -ForegroundColor Cyan
}

Write-Host ""
Write-Host "Required Roles Checklist:" -ForegroundColor Yellow

$requiredRoles = @(
    @{Name="Storage Blob Data Owner"; Scope="Storage Account"},
    @{Name="Storage Queue Data Contributor"; Scope="Function Storage Account"},
    @{Name="Storage Table Data Contributor"; Scope="Function Storage Account"},
    @{Name="App Configuration Data Owner"; Scope="App Configuration"},
    @{Name="Cognitive Services OpenAI User"; Scope="Azure OpenAI"},
    @{Name="Cognitive Services User"; Scope="AI Multi-Services"},
    @{Name="Contributor"; Scope="Resource Group"}
)

foreach ($role in $requiredRoles) {
    $found = $allAssignments | Where-Object { $_.roleDefinitionName -eq $role.Name }
    if ($found) {
        Write-Host "  ✓ $($role.Name)" -ForegroundColor Green
    } else {
        Write-Host "  ✗ $($role.Name) - MISSING" -ForegroundColor Red
    }
}
```

---

## Part 8: Common Issues and Solutions

### Issue 1: "403 Forbidden" When Reading Blobs
**Cause**: Missing Storage Blob Data Owner role
**Solution**: Assign Storage Blob Data Owner role to the storage account

### Issue 2: "Queue Not Found" Error
**Cause**: Missing Storage Queue Data Contributor role
**Solution**: Assign Storage Queue Data Contributor role to the function app storage account

### Issue 3: "Configuration Not Found" Error
**Cause**: Missing App Configuration Data Owner role
**Solution**: Assign App Configuration Data Owner role to App Configuration instance

### Issue 4: "Unauthorized" When Calling Azure OpenAI
**Cause**: Missing Cognitive Services OpenAI User role
**Solution**: Assign Cognitive Services OpenAI User role to Azure OpenAI resource

### Issue 5: "Access Denied" for Document Intelligence
**Cause**: Missing Cognitive Services User role
**Solution**: Assign Cognitive Services User role to AI Multi-Services resource

### Issue 6: Role Assignment Propagation Delay
**Cause**: Role assignments can take 5-10 minutes to propagate
**Solution**: Wait a few minutes and retry, or restart the Function App

---

## Summary

### Quick Reference: Required Roles

| Role | Scope | Purpose |
|------|-------|---------|
| Storage Blob Data Owner | Data Storage Account | Read/write blobs |
| Storage Queue Data Contributor | Function Storage Account | Durable Functions queues |
| Storage Table Data Contributor | Function Storage Account | Durable Functions tables |
| App Configuration Data Owner | App Configuration | Read configuration |
| Cognitive Services OpenAI User | Azure OpenAI | Call OpenAI API |
| Cognitive Services User | AI Multi-Services | Document Intelligence, Speech-to-Text |
| Contributor | Resource Group | General resource access |
| Key Vault Secrets User | Key Vault (if used) | Read secrets |

### Next Steps

1. Run the verification script to check current roles
2. Use Azure CLI commands to assign missing roles
3. Wait 5-10 minutes for propagation
4. Test by uploading a file to the bronze container
5. Check Function App logs for any remaining errors

