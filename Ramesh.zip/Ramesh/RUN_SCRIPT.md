# How to Run the PowerShell Script

## Quick Start

### Option 1: Run with Parameters
```powershell
.\check-function-app-status.ps1 -FunctionAppName "your-function-app-name" -ResourceGroup "your-resource-group"
```

### Option 2: Use Environment Variables
```powershell
# Set environment variables first
$env:FUNCTION_APP_NAME = "your-function-app-name"
$env:RESOURCE_GROUP = "your-resource-group"

# Then run the script
.\check-function-app-status.ps1
```

### Option 3: Load from azd Environment
```powershell
# If you're using azd, load environment variables first
eval "$(azd env get-values)"  # This is for bash, for PowerShell use:
# Or manually load from .azure folder (script will auto-detect)

# Then run
.\check-function-app-status.ps1
```

## Execution Policy

If you get an execution policy error, run one of these commands:

### For Current Session Only (Recommended)
```powershell
Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope Process
.\check-function-app-status.ps1
```

### For Current User
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

### Run Without Changing Policy
```powershell
powershell -ExecutionPolicy Bypass -File .\check-function-app-status.ps1
```

## Troubleshooting

### Script Won't Run
1. Check execution policy: `Get-ExecutionPolicy`
2. Run with bypass: `powershell -ExecutionPolicy Bypass -File .\check-function-app-status.ps1`
3. Verify Azure CLI is installed: `az --version`
4. Verify you're logged in: `az account show`

### Missing Parameters Error
- Provide parameters: `.\check-function-app-status.ps1 -FunctionAppName "name" -ResourceGroup "rg"`
- Or set environment variables before running

### Azure CLI Not Found
- Install Azure CLI: https://learn.microsoft.com/cli/azure/install-azure-cli
- Verify installation: `az --version`

### Not Logged In
```powershell
az login
az account show  # Verify current subscription
```

## Example Output

When the script runs successfully, you'll see:

```
========================================
Function App Status Check
========================================
Function App: func-processing-xxxxx
Resource Group: rg-demo

1. Checking Function App Status...
   Name: func-processing-xxxxx
   State: Running
   URL: https://func-processing-xxxxx.azurewebsites.net
   Runtime: Python|3.11

2. Listing Deployed Functions...
   Found 8 function(s):
   - start_orchestrator_http
   - start_orchestrator_on_blob
   - process_blob
   - callAoai
   - callAoaiMultiModal
   - getBlobContent
   - runDocIntel
   - speechToText
   - writeToBlob

... (more status information)
```

## Next Steps After Running

1. If functions are missing, check deployment logs
2. If configuration is missing, verify app settings
3. Review Application Insights for detailed errors
4. See [DEBUG_GUIDE.md](./DEBUG_GUIDE.md) for detailed troubleshooting

