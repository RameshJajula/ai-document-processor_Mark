# PowerShell Script to Check Function App Status
# Usage: .\check-function-app-status.ps1

param(
    [string]$FunctionAppName = "",
    [string]$ResourceGroup = ""
)

# Load environment variables from azd if available
$envPath = ".\.azure"
if (Test-Path $envPath) {
    $envFiles = Get-ChildItem -Path $envPath -Filter "*.env" -ErrorAction SilentlyContinue
    if ($envFiles -and $envFiles.Count -gt 0) {
        Write-Host "Loading environment variables from $($envFiles[0].FullName)" -ForegroundColor Cyan
        Get-Content $envFiles[0].FullName | ForEach-Object {
            if ($_ -match '^([^=]+)=(.*)$') {
                $name = $matches[1].Trim()
                $value = $matches[2].Trim() -replace '^"|"$'
                if ($name -and $value) {
                    [Environment]::SetEnvironmentVariable($name, $value, "Process")
                }
            }
        }
    }
}

# Use provided values or environment variables
if ([string]::IsNullOrEmpty($FunctionAppName)) {
    $FunctionAppName = $env:FUNCTION_APP_NAME
}
if ([string]::IsNullOrEmpty($ResourceGroup)) {
    $ResourceGroup = $env:RESOURCE_GROUP
}

if ([string]::IsNullOrEmpty($FunctionAppName) -or [string]::IsNullOrEmpty($ResourceGroup)) {
    Write-Host "Error: Function App Name and Resource Group must be provided" -ForegroundColor Red
    Write-Host "Usage: .\check-function-app-status.ps1 -FunctionAppName <name> -ResourceGroup <rg>" -ForegroundColor Yellow
    Write-Host "Or set environment variables: FUNCTION_APP_NAME and RESOURCE_GROUP" -ForegroundColor Yellow
    exit 1
}

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Function App Status Check" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Function App: $FunctionAppName" -ForegroundColor White
Write-Host "Resource Group: $ResourceGroup" -ForegroundColor White
Write-Host ""

# 1. Check Function App Status
Write-Host "1. Checking Function App Status..." -ForegroundColor Green
try {
    $appStatusJson = az functionapp show `
        --name $FunctionAppName `
        --resource-group $ResourceGroup `
        --query "{Name:name, State:state, Status:defaultHostName, Runtime:siteConfig.linuxFxVersion}" `
        --output json 2>&1
    
    if ($LASTEXITCODE -eq 0 -and $appStatusJson) {
        $appStatus = $appStatusJson | ConvertFrom-Json
        Write-Host "   Name: $($appStatus.Name)" -ForegroundColor White
        Write-Host "   State: $($appStatus.State)" -ForegroundColor $(if ($appStatus.State -eq "Running") { "Green" } else { "Red" })
        Write-Host "   URL: $($appStatus.Status)" -ForegroundColor White
        Write-Host "   Runtime: $($appStatus.Runtime)" -ForegroundColor White
    } else {
        Write-Host "   Warning: Could not retrieve function app status" -ForegroundColor Yellow
        Write-Host "   Error: $appStatusJson" -ForegroundColor Red
    }
} catch {
    Write-Host "   Error checking function app status: $_" -ForegroundColor Red
    Write-Host "   Tip: Check your Azure CLI connection with 'az account show'" -ForegroundColor Yellow
}
Write-Host ""

# 2. List Functions
Write-Host "2. Listing Deployed Functions..." -ForegroundColor Green
try {
    $functionsJson = az functionapp function list `
        --name $FunctionAppName `
        --resource-group $ResourceGroup `
        --output json 2>&1
    
    if ($LASTEXITCODE -eq 0 -and $functionsJson) {
        $functions = $functionsJson | ConvertFrom-Json
        
        if ($functions.Count -eq 0) {
            Write-Host "   Warning: No functions found!" -ForegroundColor Yellow
        } else {
            Write-Host "   Found $($functions.Count) function(s):" -ForegroundColor White
            foreach ($func in $functions) {
                # Clean up function name (remove app name prefix if present)
                $funcName = $func.name
                if ($funcName -match "/") {
                    $funcName = $funcName.Split("/")[-1]
                }
                Write-Host "   - $funcName" -ForegroundColor Cyan
            }
        }
    } else {
        Write-Host "   Warning: Could not retrieve function list" -ForegroundColor Yellow
        Write-Host "   Error: $functionsJson" -ForegroundColor Red
    }
} catch {
    Write-Host "   Error listing functions: $_" -ForegroundColor Red
}
Write-Host ""

# 3. Check Deployment Status
Write-Host "3. Checking Recent Deployment..." -ForegroundColor Green
try {
    $deploymentJson = az functionapp log deployment show `
        --name $FunctionAppName `
        --resource-group $ResourceGroup `
        --output json 2>&1
    
    if ($LASTEXITCODE -eq 0 -and $deploymentJson -and $deploymentJson -notmatch "ERROR") {
        $deployment = $deploymentJson | ConvertFrom-Json
        if ($deployment) {
            Write-Host "   Deployment ID: $($deployment.id)" -ForegroundColor White
            Write-Host "   Status: $($deployment.status)" -ForegroundColor $(if ($deployment.status -eq "4") { "Green" } else { "Yellow" })
            Write-Host "   Start Time: $($deployment.startTime)" -ForegroundColor White
            Write-Host "   End Time: $($deployment.endTime)" -ForegroundColor White
        } else {
            Write-Host "   No deployment information available" -ForegroundColor Yellow
        }
    } else {
        Write-Host "   Warning: Could not retrieve deployment logs" -ForegroundColor Yellow
        Write-Host "   Note: This may be due to network issues or deployment history not available" -ForegroundColor Gray
    }
} catch {
    Write-Host "   Error checking deployment: $_" -ForegroundColor Red
}
Write-Host ""

# 4. Check Critical Configuration
Write-Host "4. Checking Critical Configuration..." -ForegroundColor Green
try {
    $settingsJson = az functionapp config appsettings list `
        --name $FunctionAppName `
        --resource-group $ResourceGroup `
        --output json 2>&1
    
    if ($LASTEXITCODE -eq 0 -and $settingsJson -and $settingsJson -notmatch "ERROR") {
        $settings = $settingsJson | ConvertFrom-Json
        
        $criticalSettings = @(
            "FUNCTIONS_WORKER_RUNTIME",
            "FUNCTIONS_EXTENSION_VERSION",
            "APP_CONFIGURATION_URI",
            "AzureWebJobsStorage__accountName",
            "DataStorage__accountName"
        )
        
        foreach ($settingName in $criticalSettings) {
            $setting = $settings | Where-Object { $_.name -eq $settingName }
            if ($setting) {
                $value = if ($setting.value.Length -gt 50) { $setting.value.Substring(0, 50) + "..." } else { $setting.value }
                Write-Host "   $settingName : $value" -ForegroundColor White
            } else {
                Write-Host "   $settingName : NOT SET" -ForegroundColor Red
            }
        }
    } else {
        Write-Host "   Warning: Could not retrieve configuration settings" -ForegroundColor Yellow
        Write-Host "   Error: $settingsJson" -ForegroundColor Red
        Write-Host "   Tip: Check Azure CLI connection and permissions" -ForegroundColor Gray
    }
} catch {
    Write-Host "   Error checking configuration: $_" -ForegroundColor Red
}
Write-Host ""

# 5. Get Function Keys
Write-Host "5. Checking Function Keys..." -ForegroundColor Green
try {
    $keysJson = az functionapp keys list `
        --name $FunctionAppName `
        --resource-group $ResourceGroup `
        --output json 2>&1
    
    if ($LASTEXITCODE -eq 0 -and $keysJson -and $keysJson -notmatch "ERROR") {
        $keys = $keysJson | ConvertFrom-Json
        if ($keys.functionKeys.default) {
            Write-Host "   Default Function Key: $($keys.functionKeys.default.Substring(0, 10))..." -ForegroundColor White
        } else {
            Write-Host "   Warning: No default function key found" -ForegroundColor Yellow
        }
    } else {
        Write-Host "   Warning: Could not retrieve function keys" -ForegroundColor Yellow
        Write-Host "   Error: $keysJson" -ForegroundColor Red
    }
} catch {
    Write-Host "   Error retrieving function keys: $_" -ForegroundColor Red
}
Write-Host ""

# 6. Check Application Insights (if available)
Write-Host "6. Checking Application Insights Connection..." -ForegroundColor Green
try {
    if ($settings) {
        $appInsightsKey = ($settings | Where-Object { $_.name -eq "APPINSIGHTS_INSTRUMENTATIONKEY" }).value
        if ($appInsightsKey) {
            Write-Host "   Application Insights: Connected" -ForegroundColor Green
        } else {
            Write-Host "   Application Insights: Not configured" -ForegroundColor Yellow
        }
    } else {
        Write-Host "   Application Insights: Cannot check (configuration not retrieved)" -ForegroundColor Yellow
    }
} catch {
    Write-Host "   Error checking Application Insights: $_" -ForegroundColor Red
}
Write-Host ""

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Status Check Complete" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Next Steps:" -ForegroundColor Yellow
Write-Host "1. Review logs: az webapp log tail --name $FunctionAppName --resource-group $ResourceGroup" -ForegroundColor White
Write-Host "2. Check Application Insights for detailed traces and errors" -ForegroundColor White
Write-Host "3. Test HTTP endpoint: See DEBUG_GUIDE.md for testing commands" -ForegroundColor White

