# PowerShell Script to Assign Missing Contributor Role
# Based on verification results

$FunctionAppName = "func-processing-xxzzexoimh2nw"
$ResourceGroup = "AzureGPTRAG-East2"
$PrincipalId = "6db79591-8525-4694-bb83-a85ed0bc2f22"  # From verification output
$SubscriptionId = "b6ac344a-ddb6-4d48-a0af-fd1ea079737b"

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Assigning Missing Contributor Role" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

Write-Host "Assigning Contributor role to Resource Group..." -ForegroundColor Green

az role assignment create `
  --assignee $PrincipalId `
  --role "Contributor" `
  --scope "/subscriptions/$SubscriptionId/resourceGroups/$ResourceGroup"

if ($LASTEXITCODE -eq 0) {
    Write-Host ""
    Write-Host "✓ Contributor role assigned successfully!" -ForegroundColor Green
    Write-Host ""
    Write-Host "Note: Role assignment may take 5-10 minutes to propagate." -ForegroundColor Yellow
    Write-Host "Run the verification script again to confirm:" -ForegroundColor White
    Write-Host "  .\Ramesh\verify-managed-identity-roles.ps1 -FunctionAppName `"$FunctionAppName`" -ResourceGroup `"$ResourceGroup`"" -ForegroundColor Cyan
} else {
    Write-Host ""
    Write-Host "✗ Error assigning role. Check the error message above." -ForegroundColor Red
}

