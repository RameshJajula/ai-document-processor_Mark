# Azure Function App Debug Guide

## Table of Contents
1. [Overview](#overview)
2. [Function App Architecture](#function-app-architecture)
3. [Checking Function App Status](#checking-function-app-status)
4. [Verifying Function Deployment](#verifying-function-deployment)
5. [Monitoring Logs and Traces](#monitoring-logs-and-traces)
6. [Error Investigation](#error-investigation)
7. [HTTP Triggers Testing](#http-triggers-testing)
8. [Common Issues and Solutions](#common-issues-and-solutions)
9. [Quick Reference Commands](#quick-reference-commands)

---

## Overview

This guide provides comprehensive debugging steps for the AI Document Processor Function App. The function app uses Azure Durable Functions to orchestrate document processing workflows.

### Key Components
- **Function App**: Python-based Azure Function App with Durable Functions
- **Triggers**: HTTP and Blob Storage triggers
- **Orchestrator**: `process_blob` - coordinates the processing pipeline
- **Activities**: Individual processing steps (Document Intelligence, Speech-to-Text, Azure OpenAI, etc.)

---

## Function App Architecture

### Functions Overview

#### 1. **HTTP Trigger Function**
- **Name**: `start_orchestrator_http`
- **Route**: `/api/client`
- **Auth Level**: Function Key
- **Purpose**: Starts orchestration via HTTP POST request
- **Input**: JSON with `name` and `uri` fields

#### 2. **Blob Trigger Function**
- **Name**: `start_orchestrator_on_blob`
- **Path**: `bronze/{name}`
- **Connection**: `DataStorage`
- **Purpose**: Automatically starts orchestration when a blob is uploaded to the bronze container

#### 3. **Orchestrator Function**
- **Name**: `process_blob`
- **Type**: Durable Functions Orchestrator
- **Purpose**: Coordinates the document processing workflow

#### 4. **Activity Functions**
- `callAoai` - Calls Azure OpenAI with text results
- `callAoaiMultiModal` - Calls Azure OpenAI with multimodal (image) input
- `getBlobContent` - Retrieves blob content
- `runDocIntel` - Extracts text using Azure Document Intelligence
- `speechToText` - Converts audio files to text
- `writeToBlob` - Writes output JSON to blob storage

---

## Checking Function App Status

### 1. Check Function App Health (Azure Portal)

1. Navigate to Azure Portal → Your Function App
2. Go to **Overview** page
3. Check the **Status** indicator (should be "Running")
4. Verify **Runtime version** and **Platform**

### 2. Check Function App Status (Azure CLI)

```bash
# Set environment variables
eval "$(azd env get-values)"
# Or manually set:
# FUNCTION_APP_NAME="your-function-app-name"
# RESOURCE_GROUP="your-resource-group"

# Check function app status
az functionapp show \
  --name $FUNCTION_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --query "{Name:name, State:state, Status:defaultHostName, Runtime:siteConfig.linuxFxVersion}" \
  --output table

# Check if function app is running
az functionapp show \
  --name $FUNCTION_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --query "state" \
  --output tsv
```

### 3. Check Function App Configuration

```bash
# List all app settings
az functionapp config appsettings list \
  --name $FUNCTION_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --output table

# Check specific configuration
az functionapp config appsettings list \
  --name $FUNCTION_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --query "[?name=='FUNCTIONS_WORKER_RUNTIME'].{Name:name, Value:value}" \
  --output table

# Verify critical settings
az functionapp config appsettings list \
  --name $FUNCTION_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --query "[?name=='APP_CONFIGURATION_URI' || name=='FUNCTIONS_EXTENSION_VERSION' || name=='FUNCTIONS_WORKER_RUNTIME'].{Name:name, Value:value}" \
  --output table
```

### 4. Check Function App Runtime Status

```bash
# Get runtime status via admin API (requires function key)
FUNCTION_KEY=$(az functionapp keys list \
  --name $FUNCTION_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --query "functionKeys.default" \
  --output tsv)

curl -X GET \
  "https://${FUNCTION_APP_NAME}.azurewebsites.net/admin/host/status" \
  -H "x-functions-key: ${FUNCTION_KEY}" \
  | jq .
```

---

## Verifying Function Deployment

### 1. List All Deployed Functions

```bash
# List all functions in the function app
az functionapp function list \
  --name $FUNCTION_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --output table

# Get detailed function information
az functionapp function list \
  --name $FUNCTION_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --output json | jq '.[] | {name: .name, language: .language, config: .config}'
```

### 2. Verify Specific Functions

```bash
# Check if a specific function exists
FUNCTION_NAME="start_orchestrator_http"
az functionapp function show \
  --name $FUNCTION_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --function-name $FUNCTION_NAME \
  --output json

# Check function status (enabled/disabled)
az functionapp function show \
  --name $FUNCTION_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --function-name $FUNCTION_NAME \
  --query "properties.config.disabled" \
  --output tsv
```

### 3. Check Deployment Logs

```bash
# View recent deployment logs
az functionapp log deployment show \
  --name $FUNCTION_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --output table

# List all deployment logs
az functionapp log deployment list \
  --name $FUNCTION_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --output table

# Get detailed deployment log
az functionapp log deployment show \
  --name $FUNCTION_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --output json | jq .
```

### 4. Verify Function App Files (SSH/Kudu)

```bash
# Get Kudu/SCM URL
SCM_URL="https://${FUNCTION_APP_NAME}.scm.azurewebsites.net"

# Access via browser or use Kudu API
# Navigate to: https://${FUNCTION_APP_NAME}.scm.azurewebsites.net/DebugConsole

# Or use Azure CLI to check file structure
az webapp list-runtimes --linux | grep python
```

### 5. Check Package Deployment Status

```bash
# Check if deployment package is present
az functionapp deployment source show \
  --name $FUNCTION_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --output json
```

---

## Monitoring Logs and Traces

### 1. Real-Time Log Streaming

```bash
# Stream logs in real-time
az webapp log tail \
  --name $FUNCTION_APP_NAME \
  --resource-group $RESOURCE_GROUP

# Stream with specific log level
az monitor app-insights query \
  --app $APP_INSIGHTS_NAME \
  --resource-group $RESOURCE_GROUP \
  --analytics-query "traces | where timestamp > ago(1h) | order by timestamp desc" \
  --output table
```

### 2. Application Insights Queries

```bash
# Set Application Insights name
APP_INSIGHTS_NAME=$(az functionapp show \
  --name $FUNCTION_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --query "siteConfig.appSettings[?name=='APPINSIGHTS_INSTRUMENTATIONKEY']" \
  --output tsv | cut -f2)

# Or get from resource group
APP_INSIGHTS_NAME=$(az monitor app-insights component show \
  --resource-group $RESOURCE_GROUP \
  --query "[0].name" \
  --output tsv)

# Query recent traces
az monitor app-insights query \
  --app $APP_INSIGHTS_NAME \
  --resource-group $RESOURCE_GROUP \
  --analytics-query "traces | where timestamp > ago(1h) | order by timestamp desc | take 50" \
  --output table

# Query function executions
az monitor app-insights query \
  --app $APP_INSIGHTS_NAME \
  --resource-group $RESOURCE_GROUP \
  --analytics-query "traces | where message contains 'Function' | order by timestamp desc | take 50" \
  --output table

# Query errors
az monitor app-insights query \
  --app $APP_INSIGHTS_NAME \
  --resource-group $RESOURCE_GROUP \
  --analytics-query "exceptions | where timestamp > ago(24h) | order by timestamp desc | take 50" \
  --output table
```

### 3. Log Analytics Workspace Queries

```bash
# Get Log Analytics Workspace ID
WORKSPACE_ID=$(az monitor log-analytics workspace list \
  --resource-group $RESOURCE_GROUP \
  --query "[0].customerId" \
  --output tsv)

# Query using Kusto queries
az monitor log-analytics query \
  --workspace $WORKSPACE_ID \
  --analytics-query "FunctionAppLogs | where TimeGenerated > ago(1h) | order by TimeGenerated desc | take 50" \
  --output table
```

### 4. View Logs in Azure Portal

1. Navigate to Function App → **Log stream**
2. Go to **Monitor** → **Logs** for Application Insights queries
3. Use **Development Tools** → **SSH** to access console logs

### 5. Enable Detailed Logging

```bash
# Update host.json logging level (requires redeployment)
# Or update via Azure Portal: Configuration → Application settings

# Enable verbose logging temporarily
az functionapp config appsettings set \
  --name $FUNCTION_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --settings "AzureFunctionsJobHost__logging__logLevel__default=Debug"
```

---

## Error Investigation

### 1. Check Function Execution Errors

```bash
# Query exceptions from Application Insights
az monitor app-insights query \
  --app $APP_INSIGHTS_NAME \
  --resource-group $RESOURCE_GROUP \
  --analytics-query "exceptions | where timestamp > ago(24h) | project timestamp, type, outerMessage, details | order by timestamp desc" \
  --output table

# Get detailed exception information
az monitor app-insights query \
  --app $APP_INSIGHTS_NAME \
  --resource-group $RESOURCE_GROUP \
  --analytics-query "exceptions | where timestamp > ago(24h) | order by timestamp desc | take 10" \
  --output json | jq '.[] | {timestamp, type, message: .outerMessage, details: .details[0].message}'
```

### 2. Check Failed Function Executions

```bash
# Query failed function executions
az monitor app-insights query \
  --app $APP_INSIGHTS_NAME \
  --resource-group $RESOURCE_GROUP \
  --analytics-query "traces | where severityLevel >= 3 and timestamp > ago(24h) | project timestamp, message, severityLevel | order by timestamp desc" \
  --output table
```

### 3. Check Orchestration Status

```bash
# Query Durable Functions orchestration status
az monitor app-insights query \
  --app $APP_INSIGHTS_NAME \
  --resource-group $RESOURCE_GROUP \
  --analytics-query "traces | where message contains 'orchestration' or message contains 'Orchestration' | where timestamp > ago(24h) | project timestamp, message | order by timestamp desc | take 50" \
  --output table
```

### 4. Check Authentication Errors

```bash
# Query authentication/authorization errors
az monitor app-insights query \
  --app $APP_INSIGHTS_NAME \
  --resource-group $RESOURCE_GROUP \
  --analytics-query "traces | where message contains 'Unauthorized' or message contains 'Forbidden' or message contains 'authentication' | where timestamp > ago(24h) | project timestamp, message | order by timestamp desc" \
  --output table
```

### 5. Check Configuration Errors

```bash
# Query configuration-related errors
az monitor app-insights query \
  --app $APP_INSIGHTS_NAME \
  --resource-group $RESOURCE_GROUP \
  --analytics-query "traces | where message contains 'Configuration' or message contains 'config' or message contains 'APP_CONFIGURATION' | where timestamp > ago(24h) | project timestamp, message | order by timestamp desc" \
  --output table
```

### 6. Common Error Patterns

#### Storage Connection Errors
```bash
# Check for storage-related errors
az monitor app-insights query \
  --app $APP_INSIGHTS_NAME \
  --resource-group $RESOURCE_GROUP \
  --analytics-query "exceptions | where outerMessage contains 'Storage' or outerMessage contains 'blob' or outerMessage contains 'queue' | where timestamp > ago(24h) | project timestamp, outerMessage | order by timestamp desc" \
  --output table
```

#### Azure OpenAI Errors
```bash
# Check for Azure OpenAI errors
az monitor app-insights query \
  --app $APP_INSIGHTS_NAME \
  --resource-group $RESOURCE_GROUP \
  --analytics-query "exceptions | where outerMessage contains 'OpenAI' or outerMessage contains 'AOAI' | where timestamp > ago(24h) | project timestamp, outerMessage | order by timestamp desc" \
  --output table
```

---

## HTTP Triggers Testing

### 1. Get Function Keys

```bash
# List all function keys
az functionapp keys list \
  --name $FUNCTION_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --output json

# Get default function key
FUNCTION_KEY=$(az functionapp keys list \
  --name $FUNCTION_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --query "functionKeys.default" \
  --output tsv)

echo "Function Key: $FUNCTION_KEY"
```

### 2. Test HTTP Trigger Endpoint

```bash
# Test the /api/client endpoint
FUNCTION_APP_URL="https://${FUNCTION_APP_NAME}.azurewebsites.net"

# Test with sample payload
curl -X POST "${FUNCTION_APP_URL}/api/client?code=${FUNCTION_KEY}" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "test-document.pdf",
    "uri": "https://yourstorageaccount.blob.core.windows.net/bronze/test-document.pdf"
  }' \
  -v

# Test without authentication (should fail)
curl -X POST "${FUNCTION_APP_URL}/api/client" \
  -H "Content-Type: application/json" \
  -d '{"name": "test.pdf", "uri": "https://test.blob.core.windows.net/bronze/test.pdf"}' \
  -v
```

### 3. Check HTTP Trigger Status

```bash
# Query HTTP requests from Application Insights
az monitor app-insights query \
  --app $APP_INSIGHTS_NAME \
  --resource-group $RESOURCE_GROUP \
  --analytics-query "requests | where timestamp > ago(1h) | project timestamp, name, success, resultCode, duration | order by timestamp desc" \
  --output table

# Check HTTP response codes
az monitor app-insights query \
  --app $APP_INSIGHTS_NAME \
  --resource-group $RESOURCE_GROUP \
  --analytics-query "requests | where timestamp > ago(24h) | summarize count() by resultCode | order by resultCode" \
  --output table
```

### 4. Test Orchestration Status Endpoint

```bash
# After starting an orchestration, get status
INSTANCE_ID="your-instance-id-from-response"

curl -X GET "${FUNCTION_APP_URL}/runtime/webhooks/durabletask/instances/${INSTANCE_ID}?code=${FUNCTION_KEY}" \
  -H "Content-Type: application/json" | jq .

# Get orchestration history
curl -X GET "${FUNCTION_APP_URL}/runtime/webhooks/durabletask/instances/${INSTANCE_ID}/history?code=${FUNCTION_KEY}" \
  -H "Content-Type: application/json" | jq .
```

### 5. Monitor HTTP Trigger Performance

```bash
# Check average response times
az monitor app-insights query \
  --app $APP_INSIGHTS_NAME \
  --resource-group $RESOURCE_GROUP \
  --analytics-query "requests | where timestamp > ago(24h) | summarize avg(duration), max(duration), min(duration), count() by bin(timestamp, 1h) | order by timestamp desc" \
  --output table
```

---

## Common Issues and Solutions

### Issue 1: Functions Not Appearing in Portal

**Symptoms**: Deployment completes but functions don't show in Azure Portal

**Diagnosis Steps**:
```bash
# 1. Check function app status
az functionapp show --name $FUNCTION_APP_NAME --resource-group $RESOURCE_GROUP --query "state"

# 2. Check deployment logs
az functionapp log deployment show --name $FUNCTION_APP_NAME --resource-group $RESOURCE_GROUP

# 3. Check for configuration errors
az monitor app-insights query \
  --app $APP_INSIGHTS_NAME \
  --resource-group $RESOURCE_GROUP \
  --analytics-query "exceptions | where outerMessage contains 'Configuration' | where timestamp > ago(24h)"

# 4. Verify managed identity permissions
az functionapp identity show --name $FUNCTION_APP_NAME --resource-group $RESOURCE_GROUP
```

**Solutions**:
- Verify `APP_CONFIGURATION_URI` is set correctly
- Check managed identity has "App Configuration Data Reader" role
- Verify storage account connection strings
- Check for ModuleNotFound errors in logs
- Ensure `host.json` is properly formatted

### Issue 2: Storage Connection Errors

**Symptoms**: Queue not found, blob access denied errors

**Diagnosis Steps**:
```bash
# Check storage account connection
az functionapp config appsettings list \
  --name $FUNCTION_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --query "[?contains(name, 'Storage')]"

# Check managed identity roles on storage account
STORAGE_ACCOUNT=$(az functionapp config appsettings list \
  --name $FUNCTION_APP_NAME \
  --resource-group $RESOURCE_GROUP \
  --query "[?name=='DataStorage__accountName'].value" \
  --output tsv)

az role assignment list \
  --scope "/subscriptions/$(az account show --query id -o tsv)/resourceGroups/$RESOURCE_GROUP/providers/Microsoft.Storage/storageAccounts/$STORAGE_ACCOUNT" \
  --output table
```

**Solutions**:
- Ensure managed identity has "Storage Blob Data Contributor" role
- Ensure managed identity has "Storage Queue Data Contributor" role
- Verify storage account allows public access (if needed)
- Check storage account networking settings
- Verify connection string format

### Issue 3: HTTP Trigger Returns 401/403

**Symptoms**: HTTP requests fail with authentication errors

**Diagnosis Steps**:
```bash
# Check function keys
az functionapp keys list --name $FUNCTION_APP_NAME --resource-group $RESOURCE_GROUP

# Check auth level in function code (should be FUNCTION)
# Verify function key is included in request
```

**Solutions**:
- Include function key in query string: `?code=<function-key>`
- Or include in header: `x-functions-key: <function-key>`
- Regenerate function keys if compromised
- Check function app authentication settings

### Issue 4: Orchestration Not Starting

**Symptoms**: HTTP trigger succeeds but orchestration doesn't start

**Diagnosis Steps**:
```bash
# Check orchestration client binding
# Query for orchestration start events
az monitor app-insights query \
  --app $APP_INSIGHTS_NAME \
  --resource-group $RESOURCE_GROUP \
  --analytics-query "traces | where message contains 'Started orchestration' | where timestamp > ago(1h) | project timestamp, message"
```

**Solutions**:
- Verify durable client binding is correct
- Check input format matches expected schema
- Verify storage account for durable functions state
- Check for exceptions in orchestrator function

### Issue 5: Activity Functions Failing

**Symptoms**: Orchestration starts but activities fail

**Diagnosis Steps**:
```bash
# Query activity function errors
az monitor app-insights query \
  --app $APP_INSIGHTS_NAME \
  --resource-group $RESOURCE_GROUP \
  --analytics-query "exceptions | where outerMessage contains 'callAoai' or outerMessage contains 'runDocIntel' or outerMessage contains 'speechToText' | where timestamp > ago(24h) | project timestamp, outerMessage"
```

**Solutions**:
- Check activity function input parameters
- Verify Azure OpenAI endpoint and key
- Check Document Intelligence endpoint
- Verify blob access permissions
- Check for timeout issues

---

## Quick Reference Commands

### Essential Status Checks

```bash
# Set variables
eval "$(azd env get-values)"

# Function app status
az functionapp show --name $FUNCTION_APP_NAME --resource-group $RESOURCE_GROUP --query "{Name:name, State:state, Status:defaultHostName}" --output table

# List functions
az functionapp function list --name $FUNCTION_APP_NAME --resource-group $RESOURCE_GROUP --output table

# Deployment logs
az functionapp log deployment show --name $FUNCTION_APP_NAME --resource-group $RESOURCE_GROUP --output table

# Real-time logs
az webapp log tail --name $FUNCTION_APP_NAME --resource-group $RESOURCE_GROUP

# Get function key
az functionapp keys list --name $FUNCTION_APP_NAME --resource-group $RESOURCE_GROUP --query "functionKeys.default" --output tsv
```

### Application Insights Queries

```bash
# Recent traces
az monitor app-insights query --app $APP_INSIGHTS_NAME --resource-group $RESOURCE_GROUP --analytics-query "traces | where timestamp > ago(1h) | order by timestamp desc | take 50" --output table

# Recent errors
az monitor app-insights query --app $APP_INSIGHTS_NAME --resource-group $RESOURCE_GROUP --analytics-query "exceptions | where timestamp > ago(24h) | order by timestamp desc | take 20" --output table

# HTTP requests
az monitor app-insights query --app $APP_INSIGHTS_NAME --resource-group $RESOURCE_GROUP --analytics-query "requests | where timestamp > ago(1h) | project timestamp, name, success, resultCode, duration | order by timestamp desc" --output table
```

### Testing Commands

```bash
# Test HTTP endpoint
FUNCTION_KEY=$(az functionapp keys list --name $FUNCTION_APP_NAME --resource-group $RESOURCE_GROUP --query "functionKeys.default" --output tsv)
curl -X POST "https://${FUNCTION_APP_NAME}.azurewebsites.net/api/client?code=${FUNCTION_KEY}" \
  -H "Content-Type: application/json" \
  -d '{"name": "test.pdf", "uri": "https://storage.blob.core.windows.net/bronze/test.pdf"}'
```

---

## Additional Resources

- [Azure Functions Documentation](https://learn.microsoft.com/azure/azure-functions/)
- [Durable Functions Documentation](https://learn.microsoft.com/azure/azure-functions/durable/)
- [Application Insights Query Documentation](https://learn.microsoft.com/azure/azure-monitor/logs/log-query-overview)
- [Azure CLI Function App Commands](https://learn.microsoft.com/cli/azure/functionapp)

---

## Notes

- Replace `$FUNCTION_APP_NAME`, `$RESOURCE_GROUP`, and `$APP_INSIGHTS_NAME` with your actual values
- Use `eval "$(azd env get-values)"` to automatically set environment variables
- For private network deployments, use SSH or VM within the VNet to access function app
- Always check Application Insights for detailed error information
- Enable verbose logging for detailed troubleshooting

