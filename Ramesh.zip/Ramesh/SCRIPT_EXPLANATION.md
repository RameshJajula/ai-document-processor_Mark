# What Does `check-function-app-status.ps1` Do?

This PowerShell script performs a comprehensive health check of your Azure Function App. It automates multiple diagnostic checks that would otherwise require running many separate Azure CLI commands.

## Overview

The script checks 6 key areas of your Function App:
1. **Function App Status** - Is it running?
2. **Deployed Functions** - Are all functions deployed?
3. **Deployment Status** - Was the last deployment successful?
4. **Critical Configuration** - Are required settings present?
5. **Function Keys** - Can HTTP triggers be accessed?
6. **Application Insights** - Is logging configured?

## Step-by-Step Breakdown

### Step 1: Load Environment Variables (Lines 9-25)

**What it does:**
- Automatically looks for `.azure/*.env` files (created by `azd`)
- Loads environment variables like `FUNCTION_APP_NAME` and `RESOURCE_GROUP`
- Sets them in the current PowerShell session

**Why it's useful:**
- You don't have to manually set variables each time
- Works seamlessly with Azure Developer CLI (azd)

**Example:**
```powershell
# If .azure/env/.env exists with:
# FUNCTION_APP_NAME=func-processing-abc123
# RESOURCE_GROUP=rg-demo
# The script will automatically use these values
```

### Step 2: Get Function App Parameters (Lines 27-40)

**What it does:**
- Accepts parameters: `-FunctionAppName` and `-ResourceGroup`
- Falls back to environment variables if parameters aren't provided
- Validates that both values are present before proceeding

**Usage options:**
```powershell
# Option 1: Pass parameters
.\check-function-app-status.ps1 -FunctionAppName "func-app" -ResourceGroup "rg-name"

# Option 2: Use environment variables
$env:FUNCTION_APP_NAME = "func-app"
$env:RESOURCE_GROUP = "rg-name"
.\check-function-app-status.ps1

# Option 3: Auto-load from .azure folder (if using azd)
.\check-function-app-status.ps1
```

### Step 3: Check Function App Status (Lines 49-64)

**What it does:**
- Runs: `az functionapp show`
- Retrieves:
  - Function App name
  - Current state (Running, Stopped, etc.)
  - URL (defaultHostName)
  - Runtime version (e.g., Python|3.11)

**What you'll see:**
```
1. Checking Function App Status...
   Name: func-processing-abc123
   State: Running          ← Green if Running, Red if not
   URL: https://func-processing-abc123.azurewebsites.net
   Runtime: Python|3.11
```

**Why it matters:**
- Confirms the Function App exists and is operational
- Shows if it's stopped or in an error state

### Step 4: List Deployed Functions (Lines 67-85)

**What it does:**
- Runs: `az functionapp function list`
- Lists all functions deployed to the Function App
- Counts how many functions are found

**What you'll see:**
```
2. Listing Deployed Functions...
   Found 8 function(s):
   - start_orchestrator_http
   - start_orchestrator_on_blob
   - process_blob
   - callAoai
   - callAoaiMultiModal
   - getBlobContent
   - runDocIntel
   - speechToText
   - writeToBlob
```

**Why it matters:**
- Verifies all functions deployed successfully
- If count is 0, functions didn't deploy (common issue!)
- Helps identify missing functions

### Step 5: Check Deployment Status (Lines 88-106)

**What it does:**
- Runs: `az functionapp log deployment show`
- Shows the most recent deployment information:
  - Deployment ID
  - Status code (4 = Success)
  - Start and end times

**What you'll see:**
```
3. Checking Recent Deployment...
   Deployment ID: abc123-def456-...
   Status: 4              ← 4 = Success, other = Warning
   Start Time: 2025-01-15T10:30:00Z
   End Time: 2025-01-15T10:32:15Z
```

**Why it matters:**
- Confirms the last deployment completed
- Shows deployment duration
- Helps identify deployment failures

### Step 6: Check Critical Configuration (Lines 109-136)

**What it does:**
- Runs: `az functionapp config appsettings list`
- Checks for 5 critical settings:
  1. `FUNCTIONS_WORKER_RUNTIME` - Python runtime
  2. `FUNCTIONS_EXTENSION_VERSION` - Functions runtime version
  3. `APP_CONFIGURATION_URI` - App Configuration endpoint
  4. `AzureWebJobsStorage__accountName` - Storage for Functions runtime
  5. `DataStorage__accountName` - Storage for blob data

**What you'll see:**
```
4. Checking Critical Configuration...
   FUNCTIONS_WORKER_RUNTIME : python
   FUNCTIONS_EXTENSION_VERSION : ~4
   APP_CONFIGURATION_URI : https://appconfig-xxx.azconfig.io
   AzureWebJobsStorage__accountName : funcstoragexxx
   DataStorage__accountName : datastoragexxx
```

**If a setting is missing:**
```
   APP_CONFIGURATION_URI : NOT SET    ← Red text = Problem!
```

**Why it matters:**
- Missing settings cause functions to fail
- `APP_CONFIGURATION_URI` is critical for this app
- Storage settings are required for Functions runtime

### Step 7: Check Function Keys (Lines 139-154)

**What it does:**
- Runs: `az functionapp keys list`
- Retrieves the default function key
- Shows first 10 characters (for security)

**What you'll see:**
```
5. Checking Function Keys...
   Default Function Key: abc123def4...    ← Partial key shown
```

**Why it matters:**
- Function keys are required to call HTTP triggers
- Without keys, you can't test `/api/client` endpoint
- Needed for authentication

### Step 8: Check Application Insights (Lines 157-168)

**What it does:**
- Checks if `APPINSIGHTS_INSTRUMENTATIONKEY` is configured
- Verifies logging/monitoring is set up

**What you'll see:**
```
6. Checking Application Insights Connection...
   Application Insights: Connected    ← Green = Good
```

**Or if not configured:**
```
   Application Insights: Not configured    ← Yellow = Warning
```

**Why it matters:**
- Application Insights provides detailed logs and traces
- Essential for debugging function execution
- Without it, you can't query logs easily

## Complete Output Example

When you run the script, you'll see something like this:

```
========================================
Function App Status Check
========================================
Function App: func-processing-abc123
Resource Group: rg-demo

1. Checking Function App Status...
   Name: func-processing-abc123
   State: Running
   URL: https://func-processing-abc123.azurewebsites.net
   Runtime: Python|3.11

2. Listing Deployed Functions...
   Found 8 function(s):
   - start_orchestrator_http
   - start_orchestrator_on_blob
   - process_blob
   - callAoai
   - callAoaiMultiModal
   - getBlobContent
   - runDocIntel
   - speechToText
   - writeToBlob

3. Checking Recent Deployment...
   Deployment ID: abc123-def456-ghi789
   Status: 4
   Start Time: 2025-01-15T10:30:00Z
   End Time: 2025-01-15T10:32:15Z

4. Checking Critical Configuration...
   FUNCTIONS_WORKER_RUNTIME : python
   FUNCTIONS_EXTENSION_VERSION : ~4
   APP_CONFIGURATION_URI : https://appconfig-xxx.azconfig.io
   AzureWebJobsStorage__accountName : funcstoragexxx
   DataStorage__accountName : datastoragexxx

5. Checking Function Keys...
   Default Function Key: abc123def4...

6. Checking Application Insights Connection...
   Application Insights: Connected

========================================
Status Check Complete
========================================

Next Steps:
1. Review logs: az webapp log tail --name func-processing-abc123 --resource-group rg-demo
2. Check Application Insights for detailed traces and errors
3. Test HTTP endpoint: See DEBUG_GUIDE.md for testing commands
```

## What Problems Does This Script Help Identify?

### Problem 1: Functions Not Deployed
**Symptom:** Step 2 shows "Found 0 function(s)"
**Cause:** Deployment failed or functions didn't register
**Next Step:** Check deployment logs (Step 3) and Application Insights

### Problem 2: Missing Configuration
**Symptom:** Step 4 shows "NOT SET" in red
**Cause:** App settings weren't configured during deployment
**Next Step:** Add missing settings via Azure Portal or CLI

### Problem 3: Function App Stopped
**Symptom:** Step 1 shows "State: Stopped" in red
**Cause:** Function App was manually stopped or hit an error
**Next Step:** Start the Function App: `az functionapp start --name ... --resource-group ...`

### Problem 4: No Function Keys
**Symptom:** Step 5 shows "Warning: No default function key found"
**Cause:** Keys weren't generated or were deleted
**Next Step:** Regenerate keys or check authentication settings

## Azure CLI Commands It Runs

The script essentially runs these Azure CLI commands for you:

```bash
# 1. Get Function App status
az functionapp show --name <name> --resource-group <rg>

# 2. List functions
az functionapp function list --name <name> --resource-group <rg>

# 3. Get deployment logs
az functionapp log deployment show --name <name> --resource-group <rg>

# 4. List app settings
az functionapp config appsettings list --name <name> --resource-group <rg>

# 5. Get function keys
az functionapp keys list --name <name> --resource-group <rg>
```

## Benefits of Using This Script

1. **Saves Time** - One command instead of 5+ separate commands
2. **Color-Coded Output** - Green = Good, Red = Problem, Yellow = Warning
3. **Error Handling** - Continues checking even if one step fails
4. **Automatic Detection** - Finds environment variables automatically
5. **Comprehensive** - Checks all critical areas in one go
6. **Actionable** - Shows next steps at the end

## When to Use This Script

- ✅ After deploying the Function App
- ✅ When functions aren't appearing in the portal
- ✅ When troubleshooting deployment issues
- ✅ Before testing HTTP triggers
- ✅ As part of regular health checks
- ✅ When onboarding new team members

## Prerequisites

- Azure CLI installed and logged in (`az login`)
- PowerShell 5.1 or later
- Appropriate permissions to read Function App resources
- Function App name and Resource Group name

## See Also

- [DEBUG_GUIDE.md](./DEBUG_GUIDE.md) - Detailed debugging steps
- [QUICK_REFERENCE.md](./QUICK_REFERENCE.md) - Command reference
- [RUN_SCRIPT.md](./RUN_SCRIPT.md) - How to run the script

