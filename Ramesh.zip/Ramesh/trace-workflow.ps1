# PowerShell Script to Trace Complete Workflow in Application Insights
# Usage: .\trace-workflow.ps1 -FunctionAppName "func-app-name" -ResourceGroup "rg-name" [-InstanceId "instance-id"]

param(
    [string]$FunctionAppName = "",
    [string]$ResourceGroup = "",
    [string]$InstanceId = "",
    [int]$Hours = 1
)

# Load environment variables from azd if available
$envPath = ".\.azure"
if (Test-Path $envPath) {
    $envFiles = Get-ChildItem -Path $envPath -Filter "*.env" -ErrorAction SilentlyContinue
    if ($envFiles -and $envFiles.Count -gt 0) {
        Get-Content $envFiles[0].FullName | ForEach-Object {
            if ($_ -match '^([^=]+)=(.*)$') {
                $name = $matches[1].Trim()
                $value = $matches[2].Trim() -replace '^"|"$'
                if ($name -and $value) {
                    [Environment]::SetEnvironmentVariable($name, $value, "Process")
                }
            }
        }
    }
}

# Use provided values or environment variables
if ([string]::IsNullOrEmpty($FunctionAppName)) {
    $FunctionAppName = $env:FUNCTION_APP_NAME
}
if ([string]::IsNullOrEmpty($ResourceGroup)) {
    $ResourceGroup = $env:RESOURCE_GROUP
}

if ([string]::IsNullOrEmpty($FunctionAppName) -or [string]::IsNullOrEmpty($ResourceGroup)) {
    Write-Host "Error: Function App Name and Resource Group must be provided" -ForegroundColor Red
    Write-Host "Usage: .\trace-workflow.ps1 -FunctionAppName <name> -ResourceGroup <rg> [-InstanceId <id>] [-Hours <n>]" -ForegroundColor Yellow
    exit 1
}

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Workflow Tracing - Application Insights" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Function App: $FunctionAppName" -ForegroundColor White
Write-Host "Resource Group: $ResourceGroup" -ForegroundColor White
Write-Host "Time Range: Last $Hours hour(s)" -ForegroundColor White
Write-Host ""

# Get Application Insights name
Write-Host "1. Getting Application Insights..." -ForegroundColor Green
try {
    $appInsightsJson = az monitor app-insights component show `
        --resource-group $ResourceGroup `
        --query "[0]" `
        --output json 2>&1
    
    if ($LASTEXITCODE -ne 0) {
        Write-Host "   Error: Could not retrieve Application Insights" -ForegroundColor Red
        exit 1
    }
    
    $appInsights = $appInsightsJson | ConvertFrom-Json
    $appInsightsName = $appInsights.name
    Write-Host "   Application Insights: $appInsightsName" -ForegroundColor White
} catch {
    Write-Host "   Error: $_" -ForegroundColor Red
    exit 1
}
Write-Host ""

# If InstanceId not provided, get latest
if ([string]::IsNullOrEmpty($InstanceId)) {
    Write-Host "2. Getting Latest Orchestration Instance..." -ForegroundColor Green
    $instanceQuery = "traces | where timestamp > ago($Hours`h) | where message contains 'Started orchestration' | order by timestamp desc | take 1 | extend InstanceId = extract('([a-f0-9-]{36})', 1, message) | project InstanceId"
    
    try {
        $instanceResult = az monitor app-insights query `
            --app $appInsightsName `
            --resource-group $ResourceGroup `
            --analytics-query $instanceQuery `
            --output tsv 2>&1
        
        if ($LASTEXITCODE -eq 0 -and $instanceResult -and $instanceResult -notmatch "ERROR") {
            $InstanceId = $instanceResult.Trim()
            Write-Host "   Latest Instance ID: $InstanceId" -ForegroundColor White
        } else {
            Write-Host "   Warning: No orchestration instances found in last $Hours hour(s)" -ForegroundColor Yellow
            Write-Host "   Showing all workflow traces instead..." -ForegroundColor Yellow
            $InstanceId = ""
        }
    } catch {
        Write-Host "   Warning: Could not get instance ID" -ForegroundColor Yellow
        $InstanceId = ""
    }
    Write-Host ""
}

# Trace complete workflow
Write-Host "3. Tracing Complete Workflow..." -ForegroundColor Green
Write-Host ""

if ($InstanceId) {
    $workflowQuery = @"
traces
| where timestamp > ago($Hours`h)
| where message contains '$InstanceId' or customDimensions contains '$InstanceId'
| extend Step = case(
    message contains 'Blob Trigger', '1. Blob Upload',
    message contains 'process_blob' or message contains 'Process Blob', '2. Orchestrator',
    message contains 'runDocIntel', '3. Document Intelligence',
    message contains 'speechToText', '3. Speech-to-Text',
    message contains 'callAoai', '4. Azure OpenAI',
    message contains 'writeToBlob', '5. Write Output',
    'Other'
)
| project timestamp, Step, message, severityLevel
| order by timestamp asc
"@
} else {
    $workflowQuery = @"
traces
| where timestamp > ago($Hours`h)
| where message contains 'Blob Trigger' 
   or message contains 'process_blob'
   or message contains 'runDocIntel'
   or message contains 'speechToText'
   or message contains 'callAoai'
   or message contains 'writeToBlob'
| extend Step = case(
    message contains 'Blob Trigger', '1. Blob Upload',
    message contains 'process_blob' or message contains 'Process Blob', '2. Orchestrator',
    message contains 'runDocIntel', '3. Document Intelligence',
    message contains 'speechToText', '3. Speech-to-Text',
    message contains 'callAoai', '4. Azure OpenAI',
    message contains 'writeToBlob', '5. Write Output',
    'Other'
)
| project timestamp, Step, message, severityLevel
| order by timestamp asc
"@
}

try {
    Write-Host "   Querying Application Insights..." -ForegroundColor Gray
    $workflowResult = az monitor app-insights query `
        --app $appInsightsName `
        --resource-group $ResourceGroup `
        --analytics-query $workflowQuery `
        --output json 2>&1
    
    if ($LASTEXITCODE -eq 0 -and $workflowResult -and $workflowResult -notmatch "ERROR") {
        $workflowData = $workflowResult | ConvertFrom-Json
        
        if ($workflowData.tables[0].rows.Count -eq 0) {
            Write-Host "   No workflow traces found in last $Hours hour(s)" -ForegroundColor Yellow
        } else {
            Write-Host "   Found $($workflowData.tables[0].rows.Count) trace(s)" -ForegroundColor White
            Write-Host ""
            
            # Display workflow steps
            $currentStep = ""
            foreach ($row in $workflowData.tables[0].rows) {
                $timestamp = $row[0]
                $step = $row[1]
                $message = $row[2]
                $severity = $row[3]
                
                if ($step -ne $currentStep) {
                    Write-Host "   $step" -ForegroundColor Cyan
                    $currentStep = $step
                }
                
                $color = switch ($severity) {
                    "Error" { "Red" }
                    "Warning" { "Yellow" }
                    default { "White" }
                }
                
                $timeStr = if ($timestamp) { $timestamp.ToString("HH:mm:ss") } else { "" }
                Write-Host "     [$timeStr] $message" -ForegroundColor $color
            }
        }
    } else {
        Write-Host "   Error querying Application Insights" -ForegroundColor Red
        Write-Host "   $workflowResult" -ForegroundColor Red
    }
} catch {
    Write-Host "   Error: $_" -ForegroundColor Red
}
Write-Host ""

# Check for errors
Write-Host "4. Checking for Errors..." -ForegroundColor Green
$errorQuery = if ($InstanceId) {
    "exceptions | where timestamp > ago($Hours`h) | where outerMessage contains '$InstanceId' or customDimensions contains '$InstanceId' | project timestamp, outerMessage | order by timestamp desc | take 10"
} else {
    "exceptions | where timestamp > ago($Hours`h) | where outerMessage contains 'runDocIntel' or outerMessage contains 'callAoai' or outerMessage contains 'writeToBlob' or outerMessage contains 'speechToText' | project timestamp, outerMessage | order by timestamp desc | take 10"
}

try {
    $errorResult = az monitor app-insights query `
        --app $appInsightsName `
        --resource-group $ResourceGroup `
        --analytics-query $errorQuery `
        --output json 2>&1
    
    if ($LASTEXITCODE -eq 0 -and $errorResult -and $errorResult -notmatch "ERROR") {
        $errorData = $errorResult | ConvertFrom-Json
        
        if ($errorData.tables[0].rows.Count -eq 0) {
            Write-Host "   ✓ No errors found" -ForegroundColor Green
        } else {
            Write-Host "   Found $($errorData.tables[0].rows.Count) error(s):" -ForegroundColor Red
            Write-Host ""
            
            foreach ($row in $errorData.tables[0].rows) {
                $timestamp = $row[0]
                $errorMsg = $row[1]
                
                $timeStr = if ($timestamp) { $timestamp.ToString("HH:mm:ss") } else { "" }
                Write-Host "   [$timeStr] $errorMsg" -ForegroundColor Red
            }
        }
    }
} catch {
    Write-Host "   Warning: Could not check for errors" -ForegroundColor Yellow
}
Write-Host ""

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Tracing Complete" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "To trace a specific instance:" -ForegroundColor Yellow
Write-Host "  .\trace-workflow.ps1 -FunctionAppName `"$FunctionAppName`" -ResourceGroup `"$ResourceGroup`" -InstanceId `"<instance-id>`"" -ForegroundColor White
Write-Host ""
Write-Host "See END_TO_END_DEBUG_GUIDE.md for detailed queries" -ForegroundColor Yellow

