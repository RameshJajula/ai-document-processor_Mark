# How to Run Application Insights Queries - Step by Step

This guide shows you exactly how to run the tracing queries from the END_TO_END_DEBUG_GUIDE.md.

---

## Method 1: Using Azure Portal (Recommended for Beginners)

### Step 1: Access Application Insights

1. Go to [Azure Portal](https://portal.azure.com)
2. Navigate to your **Resource Group** (`AzureGPTRAG-East2`)
3. Find and click on your **Application Insights** resource
4. In the left menu, click **Logs** (under Monitoring section)

### Step 2: Run Queries in Logs

1. The **Logs** page will open with a query editor
2. Copy and paste any query from the guide
3. Click **Run** (or press F5)
4. Results will appear in a table below

---

## Method 2: Using Azure CLI (Recommended for Automation)

### Prerequisites

```powershell
# Set variables
$FUNCTION_APP_NAME = "func-processing-xxzzexoimh2nw"
$RESOURCE_GROUP = "AzureGPTRAG-East2"

# Get Application Insights name
$APP_INSIGHTS_NAME = az monitor app-insights component show `
  --resource-group $RESOURCE_GROUP `
  --query "[0].name" `
  --output tsv

Write-Host "Application Insights: $APP_INSIGHTS_NAME"
```

---

## Part 1: Step-by-Step Tracing Queries

### Step 1: File Upload Detection (Blob Trigger)

#### Azure Portal:
1. Go to Application Insights → **Logs**
2. Paste this query:
```kusto
traces
| where timestamp > ago(1h)
| where message contains "Blob Trigger" 
   or message contains "start_orchestrator_on_blob"
   or message contains "Blob Received"
| project timestamp, message, severityLevel, customDimensions
| order by timestamp desc
```
3. Click **Run**

#### Azure CLI:
```powershell
az monitor app-insights query `
  --app $APP_INSIGHTS_NAME `
  --resource-group $RESOURCE_GROUP `
  --analytics-query "traces | where timestamp > ago(1h) | where message contains 'Blob Trigger' or message contains 'start_orchestrator_on_blob' or message contains 'Blob Received' | project timestamp, message, severityLevel, customDimensions | order by timestamp desc" `
  --output table
```

**What to Look For:**
- ✅ `"Blob Trigger (start_orchestrator_on_blob) - Blob Received"`
- ✅ `"path: bronze/{filename}"`
- ✅ `"Started orchestration {instance_id}"`

---

### Step 2: Orchestrator Started

#### Azure Portal:
```kusto
traces
| where timestamp > ago(1h)
| where message contains "process_blob" 
   or message contains "Process Blob sub Orchestration"
   or message contains "Processing blob_metadata"
| project timestamp, message, severityLevel, customDimensions
| order by timestamp desc
```

#### Azure CLI:
```powershell
az monitor app-insights query `
  --app $APP_INSIGHTS_NAME `
  --resource-group $RESOURCE_GROUP `
  --analytics-query "traces | where timestamp > ago(1h) | where message contains 'process_blob' or message contains 'Process Blob sub Orchestration' or message contains 'Processing blob_metadata' | project timestamp, message, severityLevel, customDimensions | order by timestamp desc" `
  --output table
```

**What to Look For:**
- ✅ `"Process Blob sub Orchestration - Processing blob_metadata"`
- ✅ `"sub orchestration id: {instance_id}"`

---

### Step 3: File Type Detection & Routing

#### Azure Portal:
```kusto
traces
| where timestamp > ago(1h)
| where message contains "Processing audio file"
   or message contains "Processing document file"
   or message contains "Unsupported file type"
| project timestamp, message, severityLevel
| order by timestamp desc
```

#### Azure CLI:
```powershell
az monitor app-insights query `
  --app $APP_INSIGHTS_NAME `
  --resource-group $RESOURCE_GROUP `
  --analytics-query "traces | where timestamp > ago(1h) | where message contains 'Processing audio file' or message contains 'Processing document file' or message contains 'Unsupported file type' | project timestamp, message, severityLevel | order by timestamp desc" `
  --output table
```

**What to Look For:**
- ✅ `"Processing document file: {filename}"` (for PDFs, DOCX, etc.)
- ✅ `"Processing audio file: {filename}"` (for WAV, MP3, etc.)
- ⚠️ `"Unsupported file type: {extension}"` (if file type not supported)

---

### Step 4: Document Intelligence (runDocIntel)

#### Azure Portal:
```kusto
traces
| where timestamp > ago(1h)
| where message contains "runDocIntel"
   or message contains "Normalized Blob Name"
   or message contains "Starting analyze document"
   or message contains "Analyze document completed"
| project timestamp, message, severityLevel, customDimensions
| order by timestamp desc
```

#### Azure CLI:
```powershell
az monitor app-insights query `
  --app $APP_INSIGHTS_NAME `
  --resource-group $RESOURCE_GROUP `
  --analytics-query "traces | where timestamp > ago(1h) | where message contains 'runDocIntel' or message contains 'Normalized Blob Name' or message contains 'Starting analyze document' or message contains 'Analyze document completed' | project timestamp, message, severityLevel, customDimensions | order by timestamp desc" `
  --output table
```

**What to Look For:**
- ✅ `"Normalized Blob Name: {name}"`
- ✅ `"Starting analyze document: {content_preview}..."`
- ✅ `"Analyze document completed with status: {status}"`
- ❌ `"Error processing {blob_input}: {error}"` (if error occurs)

**Check for Errors:**
```powershell
az monitor app-insights query `
  --app $APP_INSIGHTS_NAME `
  --resource-group $RESOURCE_GROUP `
  --analytics-query "exceptions | where timestamp > ago(1h) | where outerMessage contains 'runDocIntel' or outerMessage contains 'DocumentIntelligence' | project timestamp, outerMessage, details | order by timestamp desc" `
  --output table
```

---

### Step 5: Speech-to-Text (speechToText)

#### Azure Portal:
```kusto
traces
| where timestamp > ago(1h)
| where message contains "speechToText"
   or message contains "Submitting transcription request"
   or message contains "Transcription completed"
   or message contains "Status: Succeeded"
| project timestamp, message, severityLevel
| order by timestamp desc
```

#### Azure CLI:
```powershell
az monitor app-insights query `
  --app $APP_INSIGHTS_NAME `
  --resource-group $RESOURCE_GROUP `
  --analytics-query "traces | where timestamp > ago(1h) | where message contains 'speechToText' or message contains 'Submitting transcription request' or message contains 'Transcription completed' or message contains 'Status: Succeeded' | project timestamp, message, severityLevel | order by timestamp desc" `
  --output table
```

**What to Look For:**
- ✅ `"Submitting transcription request for blob: {name}"`
- ✅ `"Status: Succeeded"`
- ✅ `"Transcription completed successfully!"`

---

### Step 6: Azure OpenAI Call (callAoai)

#### Azure Portal:
```kusto
traces
| where timestamp > ago(1h)
| where message contains "callAoai"
   or message contains "Full user prompt"
   or message contains "run_prompt"
   or message contains "User Prompt:"
   or message contains "System Prompt:"
| project timestamp, message, severityLevel, customDimensions
| order by timestamp desc
```

#### Azure CLI:
```powershell
az monitor app-insights query `
  --app $APP_INSIGHTS_NAME `
  --resource-group $RESOURCE_GROUP `
  --analytics-query "traces | where timestamp > ago(1h) | where message contains 'callAoai' or message contains 'Full user prompt' or message contains 'run_prompt' or message contains 'User Prompt:' or message contains 'System Prompt:' | project timestamp, message, severityLevel, customDimensions | order by timestamp desc" `
  --output table
```

**What to Look For:**
- ✅ `"callAoai.py: Full user prompt: {prompt}"`
- ✅ `"User Prompt: {user_prompt}"`
- ✅ `"System Prompt: {system_prompt}"`

**Check for Errors:**
```powershell
az monitor app-insights query `
  --app $APP_INSIGHTS_NAME `
  --resource-group $RESOURCE_GROUP `
  --analytics-query "exceptions | where timestamp > ago(1h) | where outerMessage contains 'callAoai' or outerMessage contains 'OpenAI' or outerMessage contains 'AOAI' | project timestamp, outerMessage, details | order by timestamp desc" `
  --output table
```

---

### Step 7: Write to Blob (writeToBlob)

#### Azure Portal:
```kusto
traces
| where timestamp > ago(1h)
| where message contains "writeToBlob"
   or message contains "Writing output to blob"
   or message contains "Successfully wrote output"
   or message contains "FINAL_OUTPUT_CONTAINER"
| project timestamp, message, severityLevel, customDimensions
| order by timestamp desc
```

#### Azure CLI:
```powershell
az monitor app-insights query `
  --app $APP_INSIGHTS_NAME `
  --resource-group $RESOURCE_GROUP `
  --analytics-query "traces | where timestamp > ago(1h) | where message contains 'writeToBlob' or message contains 'Writing output to blob' or message contains 'Successfully wrote output' or message contains 'FINAL_OUTPUT_CONTAINER' | project timestamp, message, severityLevel, customDimensions | order by timestamp desc" `
  --output table
```

**What to Look For:**
- ✅ `"writeToBlob.py: Writing output to blob {filename}-output.json"`
- ✅ `"writeToBlob.py: Successfully wrote output to blob {name}"`

---

### Step 8: Orchestration Completion

#### Azure Portal:
```kusto
traces
| where timestamp > ago(1h)
| where message contains "orchestration"
   or message contains "Completed"
   or message contains "Finished"
| project timestamp, message, severityLevel, customDimensions
| order by timestamp desc
```

#### Azure CLI:
```powershell
az monitor app-insights query `
  --app $APP_INSIGHTS_NAME `
  --resource-group $RESOURCE_GROUP `
  --analytics-query "traces | where timestamp > ago(1h) | where message contains 'orchestration' or message contains 'Completed' or message contains 'Finished' | project timestamp, message, severityLevel, customDimensions | order by timestamp desc" `
  --output table
```

---

## Part 2: Complete Workflow Queries

### Query 1: Single Query to See Entire Workflow

#### Get Instance ID First:
```powershell
# Get latest instance ID
$INSTANCE_ID = az monitor app-insights query `
  --app $APP_INSIGHTS_NAME `
  --resource-group $RESOURCE_GROUP `
  --analytics-query "traces | where timestamp > ago(1h) | where message contains 'Started orchestration' | order by timestamp desc | take 1 | extend InstanceId = extract('([a-f0-9-]{36})', 1, message) | project InstanceId" `
  --output tsv

Write-Host "Instance ID: $INSTANCE_ID"
```

#### Then Trace That Instance:

**Azure Portal:**
```kusto
// Replace YOUR_INSTANCE_ID with actual instance ID
let instanceId = "YOUR_INSTANCE_ID";
traces
| where timestamp > ago(24h)
| where customDimensions contains instanceId
   or message contains instanceId
| project timestamp, message, severityLevel, customDimensions
| order by timestamp asc
```

**Azure CLI:**
```powershell
az monitor app-insights query `
  --app $APP_INSIGHTS_NAME `
  --resource-group $RESOURCE_GROUP `
  --analytics-query "traces | where timestamp > ago(1h) | where customDimensions contains '$INSTANCE_ID' or message contains '$INSTANCE_ID' | project timestamp, message, severityLevel, customDimensions | order by timestamp asc" `
  --output table
```

---

### Query 2: Complete Workflow with All Steps (Recommended)

**Azure Portal:**
```kusto
traces
| where timestamp > ago(1h)
| where message contains "Blob Trigger" 
   or message contains "process_blob"
   or message contains "runDocIntel"
   or message contains "speechToText"
   or message contains "callAoai"
   or message contains "writeToBlob"
   or message contains "orchestration"
| extend Step = case(
    message contains "Blob Trigger", "1. Blob Upload",
    message contains "process_blob", "2. Orchestrator Start",
    message contains "runDocIntel", "3. Document Intelligence",
    message contains "speechToText", "3. Speech-to-Text",
    message contains "callAoai", "4. Azure OpenAI",
    message contains "writeToBlob", "5. Write Output",
    "Other"
)
| project timestamp, Step, message, severityLevel
| order by timestamp asc
```

**Azure CLI:**
```powershell
# Note: This is a complex query - use the PowerShell script instead
.\Ramesh\trace-workflow.ps1 -FunctionAppName $FUNCTION_APP_NAME -ResourceGroup $RESOURCE_GROUP
```

---

## Method 3: Using the PowerShell Script (Easiest)

### Run Complete Workflow Trace:

```powershell
# Trace latest workflow automatically
.\Ramesh\trace-workflow.ps1 `
  -FunctionAppName "func-processing-xxzzexoimh2nw" `
  -ResourceGroup "AzureGPTRAG-East2"
```

### Trace Specific Instance:

```powershell
# First get instance ID
$INSTANCE_ID = az monitor app-insights query `
  --app $APP_INSIGHTS_NAME `
  --resource-group $RESOURCE_GROUP `
  --analytics-query "traces | where timestamp > ago(1h) | where message contains 'Started orchestration' | order by timestamp desc | take 1 | extend InstanceId = extract('([a-f0-9-]{36})', 1, message) | project InstanceId" `
  --output tsv

# Then trace it
.\Ramesh\trace-workflow.ps1 `
  -FunctionAppName "func-processing-xxzzexoimh2nw" `
  -ResourceGroup "AzureGPTRAG-East2" `
  -InstanceId $INSTANCE_ID
```

---

## Quick Reference: All Steps in One Command

### PowerShell Script (Recommended):
```powershell
.\Ramesh\trace-workflow.ps1 -FunctionAppName "func-processing-xxzzexoimh2nw" -ResourceGroup "AzureGPTRAG-East2"
```

### Azure CLI (Complete Workflow):
```powershell
$APP_INSIGHTS_NAME = az monitor app-insights component show --resource-group "AzureGPTRAG-East2" --query "[0].name" --output tsv

az monitor app-insights query `
  --app $APP_INSIGHTS_NAME `
  --resource-group "AzureGPTRAG-East2" `
  --analytics-query "traces | where timestamp > ago(1h) | where message contains 'Blob Trigger' or message contains 'process_blob' or message contains 'runDocIntel' or message contains 'callAoai' or message contains 'writeToBlob' | extend Step = case(message contains 'Blob Trigger', '1. Blob Upload', message contains 'process_blob', '2. Orchestrator', message contains 'runDocIntel', '3. DocIntel', message contains 'callAoai', '4. OpenAI', message contains 'writeToBlob', '5. Write Output', 'Other') | project timestamp, Step, message | order by timestamp asc" `
  --output table
```

---

## Troubleshooting

### Query Returns No Results

1. **Check Time Range**: Increase `ago(1h)` to `ago(24h)` or `ago(7d)`
2. **Verify Function App is Running**: Check Function App status
3. **Check Application Insights Connection**: Verify APPINSIGHTS_INSTRUMENTATIONKEY is set

### Query Syntax Errors

1. **Use Azure Portal**: Portal has better error messages
2. **Check Quotes**: Ensure single quotes in Kusto queries
3. **Escape Special Characters**: Use backticks in PowerShell

### Performance Issues

1. **Limit Time Range**: Use `ago(1h)` instead of `ago(24h)`
2. **Add Filters**: Filter by specific instance ID or function name
3. **Use `take`**: Limit results with `| take 100`

---

## Example: Complete Debugging Session

### 1. Upload a file to bronze container

### 2. Get the instance ID:
```powershell
$INSTANCE_ID = az monitor app-insights query `
  --app $APP_INSIGHTS_NAME `
  --resource-group $RESOURCE_GROUP `
  --analytics-query "traces | where timestamp > ago(5m) | where message contains 'Started orchestration' | order by timestamp desc | take 1 | extend InstanceId = extract('([a-f0-9-]{36})', 1, message) | project InstanceId" `
  --output tsv
```

### 3. Trace the complete workflow:
```powershell
.\Ramesh\trace-workflow.ps1 `
  -FunctionAppName "func-processing-xxzzexoimh2nw" `
  -ResourceGroup "AzureGPTRAG-East2" `
  -InstanceId $INSTANCE_ID
```

### 4. Check for errors:
```powershell
az monitor app-insights query `
  --app $APP_INSIGHTS_NAME `
  --resource-group $RESOURCE_GROUP `
  --analytics-query "exceptions | where timestamp > ago(5m) | where outerMessage contains '$INSTANCE_ID' | project timestamp, outerMessage | order by timestamp desc" `
  --output table
```

---

## Summary

**Easiest Method**: Use the PowerShell script
```powershell
.\Ramesh\trace-workflow.ps1 -FunctionAppName "func-app" -ResourceGroup "rg-name"
```

**For Detailed Analysis**: Use Azure Portal → Application Insights → Logs

**For Automation**: Use Azure CLI commands

All queries are ready to copy-paste and run!

