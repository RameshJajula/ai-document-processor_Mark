# PowerShell Script to Verify Managed Identity Roles
# Usage: .\verify-managed-identity-roles.ps1 -FunctionAppName "func-app-name" -ResourceGroup "rg-name"

param(
    [string]$FunctionAppName = "",
    [string]$ResourceGroup = ""
)

# Load environment variables from azd if available
$envPath = ".\.azure"
if (Test-Path $envPath) {
    $envFiles = Get-ChildItem -Path $envPath -Filter "*.env" -ErrorAction SilentlyContinue
    if ($envFiles -and $envFiles.Count -gt 0) {
        Write-Host "Loading environment variables from $($envFiles[0].FullName)" -ForegroundColor Cyan
        Get-Content $envFiles[0].FullName | ForEach-Object {
            if ($_ -match '^([^=]+)=(.*)$') {
                $name = $matches[1].Trim()
                $value = $matches[2].Trim() -replace '^"|"$'
                if ($name -and $value) {
                    [Environment]::SetEnvironmentVariable($name, $value, "Process")
                }
            }
        }
    }
}

# Use provided values or environment variables
if ([string]::IsNullOrEmpty($FunctionAppName)) {
    $FunctionAppName = $env:FUNCTION_APP_NAME
}
if ([string]::IsNullOrEmpty($ResourceGroup)) {
    $ResourceGroup = $env:RESOURCE_GROUP
}

if ([string]::IsNullOrEmpty($FunctionAppName) -or [string]::IsNullOrEmpty($ResourceGroup)) {
    Write-Host "Error: Function App Name and Resource Group must be provided" -ForegroundColor Red
    Write-Host "Usage: .\verify-managed-identity-roles.ps1 -FunctionAppName <name> -ResourceGroup <rg>" -ForegroundColor Yellow
    Write-Host "Or set environment variables: FUNCTION_APP_NAME and RESOURCE_GROUP" -ForegroundColor Yellow
    exit 1
}

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Managed Identity Roles Verification" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Function App: $FunctionAppName" -ForegroundColor White
Write-Host "Resource Group: $ResourceGroup" -ForegroundColor White
Write-Host ""

# Get managed identity
Write-Host "1. Retrieving Managed Identity..." -ForegroundColor Green
try {
    $identityJson = az functionapp identity show `
        --name $FunctionAppName `
        --resource-group $ResourceGroup `
        --output json 2>&1
    
    if ($LASTEXITCODE -ne 0 -or $identityJson -match "ERROR") {
        Write-Host "   Error: Could not retrieve managed identity" -ForegroundColor Red
        Write-Host "   $identityJson" -ForegroundColor Red
        exit 1
    }
    
    $identity = $identityJson | ConvertFrom-Json
    $principalId = ($identity.userAssignedIdentities.PSObject.Properties | Select-Object -First 1).Value.principalId
    $clientId = ($identity.userAssignedIdentities.PSObject.Properties | Select-Object -First 1).Value.clientId
    $identityName = ($identity.userAssignedIdentities.PSObject.Properties | Select-Object -First 1).Name
    
    Write-Host "   Managed Identity Name: $identityName" -ForegroundColor White
    Write-Host "   Principal ID: $principalId" -ForegroundColor White
    Write-Host "   Client ID: $clientId" -ForegroundColor White
} catch {
    Write-Host "   Error: $_" -ForegroundColor Red
    exit 1
}
Write-Host ""

# Get all role assignments
Write-Host "2. Retrieving Role Assignments..." -ForegroundColor Green
try {
    $allAssignmentsJson = az role assignment list `
        --assignee $principalId `
        --all `
        --output json 2>&1
    
    if ($LASTEXITCODE -ne 0) {
        Write-Host "   Warning: Could not retrieve role assignments" -ForegroundColor Yellow
        $allAssignments = @()
    } else {
        $allAssignments = $allAssignmentsJson | ConvertFrom-Json
        Write-Host "   Found $($allAssignments.Count) role assignment(s)" -ForegroundColor White
    }
} catch {
    Write-Host "   Error retrieving role assignments: $_" -ForegroundColor Red
    $allAssignments = @()
}
Write-Host ""

# Display current role assignments
Write-Host "3. Current Role Assignments:" -ForegroundColor Green
if ($allAssignments.Count -eq 0) {
    Write-Host "   No role assignments found!" -ForegroundColor Red
} else {
    $allAssignments | ForEach-Object {
        $scopeName = $_.scope.Split('/')[-1]
        Write-Host "   - $($_.roleDefinitionName)" -ForegroundColor Cyan
        Write-Host "     Scope: $scopeName" -ForegroundColor Gray
    }
}
Write-Host ""

# Check required roles
Write-Host "4. Required Roles Checklist:" -ForegroundColor Green
Write-Host ""

$requiredRoles = @(
    @{Name="Storage Blob Data Owner"; Description="Read/write blobs in storage account"},
    @{Name="Storage Queue Data Contributor"; Description="Durable Functions queue operations"},
    @{Name="Storage Table Data Contributor"; Description="Durable Functions table operations"},
    @{Name="App Configuration Data Owner"; Description="Read App Configuration settings"},
    @{Name="Cognitive Services OpenAI User"; Description="Call Azure OpenAI API"},
    @{Name="Cognitive Services User"; Description="Access Document Intelligence and Speech-to-Text"},
    @{Name="Contributor"; Description="Resource group access"}
)

$missingRoles = @()
foreach ($role in $requiredRoles) {
    $found = $allAssignments | Where-Object { $_.roleDefinitionName -eq $role.Name }
    if ($found) {
        $scopeName = $found.scope.Split('/')[-1]
        Write-Host "   ✓ $($role.Name)" -ForegroundColor Green
        Write-Host "     Scope: $scopeName" -ForegroundColor Gray
    } else {
        Write-Host "   ✗ $($role.Name) - MISSING" -ForegroundColor Red
        Write-Host "     Purpose: $($role.Description)" -ForegroundColor Yellow
        $missingRoles += $role
    }
    Write-Host ""
}

# Summary
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Summary" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan

$assignedCount = $requiredRoles.Count - $missingRoles.Count
Write-Host "Roles Assigned: $assignedCount / $($requiredRoles.Count)" -ForegroundColor $(if ($assignedCount -eq $requiredRoles.Count) { "Green" } else { "Yellow" })

if ($missingRoles.Count -gt 0) {
    Write-Host ""
    Write-Host "Missing Roles:" -ForegroundColor Red
    $missingRoles | ForEach-Object {
        Write-Host "  - $($_.Name)" -ForegroundColor Red
    }
    Write-Host ""
    Write-Host "Next Steps:" -ForegroundColor Yellow
    Write-Host "1. See MANAGED_IDENTITY_ROLES_GUIDE.md for Azure CLI commands to assign roles" -ForegroundColor White
    Write-Host "2. Or use Azure Portal: Resource → Access control (IAM) → Add role assignment" -ForegroundColor White
    Write-Host "3. Wait 5-10 minutes for role propagation after assignment" -ForegroundColor White
} else {
    Write-Host ""
    Write-Host "✓ All required roles are assigned!" -ForegroundColor Green
    Write-Host ""
    Write-Host "Note: If you're still experiencing errors, check:" -ForegroundColor Yellow
    Write-Host "  - Role assignments are on the correct scope (storage account, app config, etc.)" -ForegroundColor White
    Write-Host "  - Wait time for role propagation (5-10 minutes)" -ForegroundColor White
    Write-Host "  - Function App logs for specific error messages" -ForegroundColor White
}

Write-Host ""

